package es.ercilla.almacen.productos;

import java.util.Arrays;

/**
 * Gestión del Almacén
 */
public class Almacen {

	public static Producto[] productos = new Producto[5];

	/**
	 * Método principal
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// Creaciones
		Almacen almacen = new Almacen();
		Producto producto = new Producto(1, "Ferretería", 5);
		Producto producto2 = new Producto(2, "Perfumería", 150);
		Producto producto3 = new Producto(3, "Hogar", 50);
		Producto producto4 = new Producto(4, "Tecnología", 300);
		Producto producto5 = new Producto(5, "Imagen y Sonido", 700);
		Producto producto6 = new Producto(6, "Moda", 200);
		Producto producto7 = new Producto(7, "Cosmética", 75);
		Producto producto8 = new Producto(8, "Alimentación", 125);

		// Inserciones
		System.out.println(almacen.insertarProducto(producto));
		System.out.println("Productos en Almacén: " + Arrays.toString(productos));
		System.out.println(almacen.insertarProducto(producto2));
		System.out.println("Productos en Almacén: " + Arrays.toString(productos));
		System.out.println(almacen.insertarProducto(producto3));
		System.out.println("Productos en Almacén: " + Arrays.toString(productos));
		System.out.println(almacen.insertarProducto(producto4));
		System.out.println("Productos en Almacén: " + Arrays.toString(productos));
		System.out.println(almacen.insertarProducto(producto5));
		System.out.println("Productos en Almacén: " + Arrays.toString(productos));

		// Fuera de rango
//		System.out.println(almacen.insertarProducto(producto6));
//		System.out.println("Productos en Almacén: " + Arrays.toString(productos));

		// Modificaciones de precio
		System.out.println(almacen.modificarPrecioProducto(producto, 2500));
		System.out.println("Productos en Almacén: " + Arrays.toString(productos));

		// No existe
//		System.out.println(almacen.modificarPrecioProducto(producto6, 2500));
//		System.out.println("Productos en Almacén: " + Arrays.toString(productos));

		// Borrados
		System.out.println(almacen.eliminarProducto(producto));
		System.out.println("Productos en Almacén: " + Arrays.toString(productos));

		// No existe
//		System.out.println(almacen.eliminarProducto(producto6));
//		System.out.println("Productos en Almacén: " + Arrays.toString(productos));
	}

	/**
	 * Inserta un Producto en el Almacén
	 * 
	 * @param producto a insertar
	 * @return String con el resultado de la operación
	 */
	public String insertarProducto(Producto producto) {
		int hueco = quedaEspacioEnAlmacen();
		String resultado = "";
		if (hueco != -1) {
			productos[hueco] = producto;
			resultado = "Se ha insertado: " + producto.toString();
		} else {
			resultado = "Ya existe o no hay hueco para: " + producto.toString();
		}
		return resultado;
	}

	/**
	 * Modifica el precio de un Producto
	 * 
	 * @param producto    que queremos modificar
	 * @param nuevoPrecio con el valor del nuevo importe
	 * @return String con el resultado de la operación
	 */
	public String modificarPrecioProducto(Producto producto, int nuevoPrecio) {
		String resultado = "";
		int hueco = existeProductoEnAlmacen(producto);
		if (hueco != -1) {
			productos[hueco].setPrecio(nuevoPrecio);
			resultado = "Se ha actualizado correctamente el precio: " + productos[hueco].toString();
		} else {
			resultado = "El producto " + producto.toString() + " no existe en el Almacén";
		}
		return resultado;
	}

	/**
	 * Elimina un Producto del Almacén
	 * 
	 * @param producto a eliminar
	 * @return String con el resultado de la operación
	 */
	public String eliminarProducto(Producto producto) {
		int hueco = existeProductoEnAlmacen(producto);
		String resultado = "";
		if (hueco != -1) {
			productos[hueco] = null;
			resultado = "Se ha eliminado correctamente el producto: " + producto.toString();
		} else {
			resultado = "El producto " + producto.toString() + " no existe en el Almacén";
		}
		return resultado;
	}

	/**
	 * Comprueba si queda espacio en el Almacén
	 * 
	 * @return índice con el primer hueco libre que encuentra, -1 si no hay espacio
	 */
	private int quedaEspacioEnAlmacen() {
		int hueco = -1;
		for (int i = 0; i < productos.length; i++) {
			if (productos[i] == null) {
				hueco = i;
				return hueco;
			}
		}
		return hueco;
	}

	/**
	 * Comprueba si existe un Producto en el Almacén
	 * 
	 * @return índice con el hueco que ocupa el Producto si está en el almacén, -1
	 *         si no está
	 */
	private int existeProductoEnAlmacen(Producto producto) {
		int hueco = -1;
		for (int i = 0; i < productos.length; i++) {
			if (productos[i] != null && productos[i].equals(producto)) {
				hueco = i;
				return hueco;
			}
		}
		return hueco;
	}

}
