package es.ercilla.arrays;

public class Ejercicio1 {

	public static void main(String[] args) {

		int[] numeros = { 4, 7, 2, 9, 5, 3 };
		int suma = 0;

		for (int i = 0; i < numeros.length; i++) {
			System.out.println("Número: " + numeros[i]);
			suma += numeros[i];
		}

		System.out.println("Suma total: " + suma);
	}
}
