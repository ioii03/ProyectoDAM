package es.ercilla.almacen.productos;

import java.util.Objects;

/**
 * Clase bean de producto
 */
public class Producto {
	private int idProducto;
	private String categoria;
	private int precio;

	public Producto(int idProducto, String categoria, int precio) {
		super();
		this.idProducto = idProducto;
		this.categoria = categoria;
		this.precio = precio;
	}

	public int getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(int idProducto) {
		this.idProducto = idProducto;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public int getPrecio() {
		return precio;
	}

	public void setPrecio(int precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "Producto [idProducto=" + idProducto + ", categoria=" + categoria + ", precio=" + precio + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Producto other = (Producto) obj;
		return Objects.equals(categoria, other.categoria) && idProducto == other.idProducto && precio == other.precio;
	}

}
