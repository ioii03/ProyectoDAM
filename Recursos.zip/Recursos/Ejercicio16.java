package es.ercilla.arrays;

public class Ejercicio16 {
	public static void main(String[] args) {
		int[] numeros = { 1, 2, 3, 4, 5, 6, 7 };
		int posiciones = 3;
		int[] resultado = new int[numeros.length];
		posiciones = posiciones % numeros.length;
		// Versión con vector auxiliar
		for (int i = 0; i < numeros.length; i++) {
			int nuevaPosicion = (i + posiciones) % numeros.length;
			resultado[nuevaPosicion] = numeros[i];
		}
		System.out.println("Con vector auxiliar:");
		for (int i = 0; i < resultado.length; i++) {
			System.out.print(resultado[i] + " ");
		}
		// Versión sin vector auxiliar
		for (int i = 0; i < posiciones; i++) {
			int ultimo = numeros[numeros.length - 1];
			for (int j = numeros.length - 1; j > 0; j--) {
				numeros[j] = numeros[j - 1];
			}
			numeros[0] = ultimo;
		}
		System.out.println("\nSin vector auxiliar:");
		for (int i = 0; i < numeros.length; i++) {
			System.out.print(numeros[i] + " ");
		}
	}
}
