package es.ercilla.arrays;

public class Ejercicio2 {

	public static void main(String[] args) {

		int[] numeros = { 12, 7, 9, 20, 15, 8, 3, 6 };

		int pares = 0;
		int impares = 0;

		System.out.println("Números pares:");

		for (int i = 0; i < numeros.length; i++) {
			if (numeros[i] % 2 == 0) {
				System.out.print(numeros[i] + " ");
				pares++;
			}
		}

		System.out.println("\nNúmeros impares:");

		for (int i = 0; i < numeros.length; i++) {
			if (numeros[i] % 2 != 0) {
				System.out.print(numeros[i] + " ");
				impares++;
			}
		}

		System.out.println("\nCantidad de pares: " + pares);
		System.out.println("Cantidad de impares: " + impares);
	}
}
