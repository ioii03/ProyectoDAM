package es.ercilla.arrays;

public class Ejercicio3 {

	public static void main(String[] args) {

		int[] numeros = { 14, 3, 28, 9, 35, 11, 2 };

		int maximo = numeros[0];
		int minimo = numeros[0];

		int posicionMax = 0;
		int posicionMin = 0;

		for (int i = 1; i < numeros.length; i++) {

			if (numeros[i] > maximo) {
				maximo = numeros[i];
				posicionMax = i;
			}

			if (numeros[i] < minimo) {
				minimo = numeros[i];
				posicionMin = i;
			}
		}

		System.out.println("Máximo: " + maximo);
		System.out.println("Posición: " + posicionMax);

		System.out.println("Mínimo: " + minimo);
		System.out.println("Posición: " + posicionMin);
	}
}
