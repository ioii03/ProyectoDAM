package vectores.ejercicios;

import java.util.Arrays;

/*
5. Desplazamiento de elementos
Dado el siguiente vector: {1, 2, 3, 4, 5, 6}
Desarrolla un programa que desplace todos los elementos una
posición hacia la derecha. El último elemento deberá pasar a
ocupar la primera posición.
No se permite utilizar un vector auxiliar.
*/
public class DesplazarElementos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] vector= {1, 2, 3, 4, 5, 6};
		//int aux=vector[vector.length-1];;
		//int aux2=0;
		//int aux3=0;
		int a=vector.length-1;
		//System.out.println(aux);
		for( int i=0; i<vector.length;i++) {
			//aux2=vector[i];
			//aux3=vector[i]-vector[0];
			vector[0]=vector[a];
			vector[i]=i;
			
			//System.out.print(aux2+" ");

			//vector[aux-vector.length]=aux2;
			//vector[i]=i;
			
			
		}	
		System.out.println("\n"+Arrays.toString(vector));
		//System.out.println(aux);
		
		
	}

}
