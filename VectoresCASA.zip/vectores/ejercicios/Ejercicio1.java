package vectores.ejercicios;

import java.util.Arrays;

/**
 * 1. Invertir un vector Dado el siguiente vector: {10, 20, 30, 40, 50}
 * Desarrolla un programa que muestre el vector original y después sus elementos
 * en orden inverso. Como ampliación, realiza una versión que invierta el
 * contenido del propio vector, sin utilizar otro array auxiliar.
 */
public class Ejercicio1 {

	public static void main(String[] args) {
		int[] numeros = { 10, 20, 30, 40, 50 };
		int[] aux = new int[numeros.length];
		System.out.println("Vector Original: " + Arrays.toString(numeros));
		for (int i = 0; i < numeros.length; i++) {

			// System.out.println(numeros[i]);
		}
		System.out.print("\nVector invertido fuera del array:");
		Ejercicio1.numInverso(aux, numeros, numeros.length);
	}

	public static void numInverso(int[]aux, int[] numeros, int anum) {

		
		 
		 
		for (int j = numeros.length - 1; j >= 0; j--) {
			//Ejercicio1[] aux = new Ejercicio1[numeros.length];
			int reverso;
			reverso = numeros[j];
			//aux[j]=reverso;
			System.out.print(" " + reverso);
			
			for (int k=0;k<numeros.length;k++) {
				aux[k]=numeros[j];
			}

		}
		System.out.print("\n");
		System.out.println("\n" + "Vector Invertido: " + Arrays.toString(aux));

	}

}
