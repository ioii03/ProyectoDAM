package vectores.ejercicios;

import java.util.Arrays;

/*
4. Fusionar dos vectores
Se dispone de dos vectores: {3, 6, 9, 12} y {2, 4, 8}
Desarrolla un programa que cree un tercer vector con capacidad
suficiente para almacenar todos los elementos de ambos.
Primero se copiarán los elementos del primer vector y después los
del segundo, conservando su orden original.
Finalmente, calcula la media aritmética de todos los elementos
del vector resultante.
*/
public class FusionarVectores {

	public static void main(String[] args) {
		int[] v1= {3,6,9,12};
		int[] v2= {2,4,8};
		int[] v3= new int[v1.length+v2.length];
		int media=0;
		for(int i=0; i<v1.length;i++) {
			int aux=0;
			aux=v1[i];
			v3[i]=aux;
			for(int j=0; j<v2.length;j++) {
				aux=v2[j];
				v3[j+v1.length]=aux;
			}
		}
		for(int i=0; i<v3.length;i++) {
			media+=v3[i];
			
		}
		System.out.println(Arrays.toString(v3));
		System.out.println(media/v3.length);
	}

}
