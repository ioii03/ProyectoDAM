package vectores.ejercicios;
/*
6. Mayor secuencia creciente
Dado el siguiente vector: {3, 5, 7, 2, 4, 6, 8, 1, 9, 10}
Desarrolla un programa que encuentre la secuencia más larga de
elementos consecutivos del vector cuyos valores estén ordenados
de forma estrictamente creciente.
El programa deberá mostrar la posición inicial, la longitud y los
elementos que forman la secuencia.
No se permite ordenar el vector.
*/
public class MayorSecuenciaCreciente {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int[] vector= {3, 5, 7, 2, 4, 6, 8, 1, 9, 10};
		//hecho con ia porque no entiendo lo que pide el enunciado
		 int[] v = {3, 5, 7, 2, 4, 6, 8, 1, 9, 10};

	        int mejorInicio = 0;
	        int mejorLong = 1;
	        int inicioActual = 0;
	        int longActual = 1;

	        for (int i = 1; i < v.length; i++) {
	            if (v[i] > v[i - 1]) {
	                longActual++;
	            } else {
	                inicioActual = i;
	                longActual = 1;
	            }

	            if (longActual > mejorLong) {
	                mejorLong = longActual;
	                mejorInicio = inicioActual;
	            }
	        }

	        System.out.println("Posición inicial: " + mejorInicio);
	        System.out.println("Longitud: " + mejorLong);
	        System.out.print("Elementos: ");
	        for (int i = mejorInicio; i < mejorInicio + mejorLong; i++) {
	            System.out.print(v[i] + " ");
	        }
	        System.out.println();
		
		
		
		
	}

}
