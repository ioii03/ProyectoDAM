package vectores.ejercicios;

import java.util.Arrays;

/*
7. Análisis de temperaturas Enunciado 
Una estación meteorológica almacena las temperaturas registradas 
durante 14 días consecutivos: {18.5, 20.3, 21.8, 19.6, 23.1, 25.4, 
22.0, 21.5, 26.3, 27.1, 24.8, 20.2, 19.4, 23.7} 
Desarrolla un programa que calcule la temperatura media del 
periodo, la máxima y mínima registradas y sus correspondientes 
días, y el número de días cuya temperatura supera la media. 
Además, debe localizar la mayor secuencia de días consecutivos en 
los que la temperatura aumenta respecto al día anterior. 
Se mostrará la longitud de dicha secuencia, el día en el que 
comienza y las temperaturas que la forman. Los días se numerarán 
desde el 1. 
*/
public class AnalisisTemp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double[] vector= {18.5,20.3,21.8,19.6,23.1,25.4,22.0,21.5,26.3,27.1,24.8,20.2,19.4,23.7};
		double media=0;
		double max=vector[0];
		double min=vector[0];
		int dmax=0;
		int dmin=0;
		double smed=0;
		int dia=0;
		
		
		for(int i=0;i<vector.length;i++) {
			media+=vector[i];
			
			if(max<=vector[i]) { 
				max=vector[9];
				dmax=i+1;
				}
			if(min>=vector[i]){
				min=vector[i];
				dmin=i+1;
				}
			
		}
		media/=vector.length;
		for(int j=0;j<vector.length;j++) {
			if(media>vector[j]) {
				dia++;
			}
		}
		
		
		System.out.println("Temperaturas: "+Arrays.toString(vector));
		System.out.print("Media: "+(float)media+"ºC");
		System.out.println("Temperatura máxima: "+max+"ºC --> Día: "+dmax);
		System.out.println("Temperatura mínima: "+min+"ºC --> Día: "+dmin);
		System.out.println("Dias donde la temperatura supera la media: "+dia);
		
				
		
	}

}
