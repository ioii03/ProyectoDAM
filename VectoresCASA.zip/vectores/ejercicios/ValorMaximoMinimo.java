package vectores.ejercicios;

/*2. Valor máximo y mínimo
Dado el siguiente vector: {14, 3, 28, 9, 35, 11, 2}
Desarrolla un programa que determine el valor máximo y el mínimo,
indicando la posición que ocupan dentro del vector. No está permitido ordenar los elementos.
*/
public class ValorMaximoMinimo {

	public static void main(String[] args) {
		
		int[] vector= {14,3,28,9,35,11,2,34,4};
		int max=vector[0]; // valor maximo del vector, se empeza en [0] para tomar como primera referencia el primer valor del array
		int min=vector[0]; // valor minimo vecto, lo mismo que el de arriba pero menor valor
		//int pos; // innecesario(con poner solo +i vale pero dejo esto para guiarme
		int nmax=0; // literalmente explicado en el S.O.P
		int nmin=0; // Leer lo de arriba ^^^^
		
		for(int i=0;i<vector.length;i++) {
			if(max<=vector[i]) { 
				max=vector[i];
				System.out.println("Max: "+max+" posicion: "+i);
				nmax++;
			}else if(min>=vector[i]){
				min=vector[i];
				System.out.println("Min: "+min+" posicion: "+i);
				nmin++;
				}
		}
		System.out.println("Cantidad de Nº hasta llegar al valor maximo: "+nmax);
		System.out.println("Cantidad de Nº hasta llegar al valor minimo: "+nmin);

	}
	

}
