package vectores.ejercicios;
/*
3. Notas de alumnos

Un profesor almacena las notas de seis alumnos en el siguiente vector: {6.5, 8.0, 4.5, 9.2, 3.0, 7.5}
Desarrolla un programa que calcule la nota media del grupo, el
número de alumnos aprobados y suspensos, y cuántos alumnos tienen
una nota superior a la media.
Se considera aprobado al alumno que obtiene una nota igual o
superior a 5.
*/

public class NotasAlumnos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double[] notas={6.5, 8.0, 4.5, 9.2, 3.0, 7.5}; //array que nos dan
		double media=0; // nota media
		int app=0; // llevar la cuenta de aprobados
		int sup=0; // llevar la cuenta de suspensos
		for(int i=0; i<notas.length;i++) { // bucle tipico
			if(notas[i]>=5) { // si <5 aprobado
				app++;
			}else {sup++;} // sino suspenso 
			double nota=notas[i]; // notas[i] pero §fancy§
			media+=nota; // media = nota+media 
		} 
	System.out.println("Aprobados: "+app+"\nSuspensos: "+sup+"\nMedia: "+media/notas.length/*Esto es la media de verdad*/);
	
	
	
	
	
	}

}
