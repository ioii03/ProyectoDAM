package vectores.ejercicios;

import java.util.Arrays; // Importación necesaria para usar Arrays.toString

public class InvertirVector {
    public static void main(String[] args) {
        // Vector original
        int[] vector = {10, 20, 30, 40, 50, /*numero extra para ver si todo va bien*//*60,70,80,90,100*/};
        // --- VERSIÓN 2 (Ampliación): Invertir el propio vector (In-place) ---
        System.out.println("--- Versión 2 (Ampliación): Invertir contenido sin array auxiliar ---\n");
        System.out.println("Vector original: " + Arrays.toString(vector));//+"\n-------------------------------------");
        int izquierda = 0;
        int bucle=1;
        int derecha = vector.length - 1; // vector.length - 1 = 4

        do{
        	System.out.println("\n-----------------"+(bucle)+"º BUCLE-------------------\n");//
        	int temporal = vector[izquierda]; // int temporal para girar las posiciones de los nuemros dentro del vector
System.out.println("Vector[izquierda]: "+vector[izquierda]); // literalmente el valor del vector empezando por la izquierda			
System.out.println("vector[izquierda] = vector[derecha]: "+(vector[izquierda] = vector[derecha])); //cambio en la variable para que comienze a contrar desde el 50 para atras
System.out.println("vector[derecha] = temporal: "+(vector[derecha] = temporal)); //

System.out.println("izquierda++: "+izquierda++); // suma 1 a la variable izquierda//lo que pone abajo \/
System.out.println("derecha--: "+derecha--); // resta 1 a la variable derecha // asi podra cerrar el bucle
System.out.println("Vector modificado: " + Arrays.toString(vector)); // S.O.P para ver el desarrollo del bucle
bucle++;
        }while (izquierda < derecha);

        // Impresión usando Arrays.toString
        System.out.println("\nVector original final modificado: " + Arrays.toString(vector));
    }
}
