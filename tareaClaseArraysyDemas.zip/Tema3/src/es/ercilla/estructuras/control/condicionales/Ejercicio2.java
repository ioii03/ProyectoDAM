package es.ercilla.estructuras.control.condicionales;

public class Ejercicio2 {

	public static void main(String[] args) {

		int edad = 24;
		double sueldo = 2850;
		double prestamo = 22000;

		double cuota = 410;
		double deudas = 300;

		boolean indefinido = true;

		double porcentaje = (cuota + deudas) / sueldo * 100;

		if (edad < 21 || edad > 65) {

			System.out.println("DENEGADO");

		} else if (edad < 25 && prestamo > 20000) {

			System.out.println("DENEGADO POR EDAD");

		} else if (!indefinido && sueldo < 2500) {

			System.out.println("DENEGADO POR CONTRATO");

		} else if (porcentaje > 40) {

			System.out.println("DENEGADO POR ENDEUDAMIENTO");

		} else {

			System.out.println("CONCEDIDO");
		}

		System.out.println(porcentaje);
	}
}