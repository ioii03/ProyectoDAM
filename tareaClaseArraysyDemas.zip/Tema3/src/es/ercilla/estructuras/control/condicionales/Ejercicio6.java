package es.ercilla.estructuras.control.condicionales;

public class Ejercicio6 {

	public static void main(String[] args) {

		boolean tarjeta = true;
		int nivel = 2;
		int hora = 23;
		boolean informatica = true;

		if (!tarjeta) {

			System.out.println("DENEGADO");

		} else if (hora >= 8 && hora <= 20 && nivel >= 2) {

			System.out.println("AUTORIZADO");

		} else if ((hora < 8 || hora > 20) && nivel == 3 && informatica) {

			System.out.println("AUTORIZADO");

		} else {

			System.out.println("DENEGADO");
		}
	}
}
