package es.ercilla.estructuras.control.condicionales;

public class Ejercicio1 {

	public static void main(String[] args) {

		int consumo = 620;
		boolean placas = true;
		boolean electrico = true;
		int nocturno = 65;

		String tarifa;

		if (placas && electrico) {

			if (consumo > 700) {
				tarifa = "C";
			} else {
				tarifa = "B";
			}

		} else if (electrico && nocturno > 50) {

			tarifa = "C";

		} else if (placas && consumo < 300) {

			tarifa = "A";

		} else if (consumo < 200) {

			tarifa = "A";

		} else if (consumo <= 500) {

			tarifa = "B";

		} else {

			tarifa = "C";
		}

		System.out.println("Tarifa: " + tarifa);
	}
}
