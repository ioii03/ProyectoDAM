package es.ercilla.estructuras.control.condicionales;

public class Ejercicio7 {

	public static void main(String[] args) {

		int noches = 8;
		double precioNoche = 90;

		boolean temporadaAlta = true;
		boolean habitual = true;
		int anticipacion = 70;

		double total = noches * precioNoche;

		if (temporadaAlta) {
			total = total * 1.20;
		}

		double descuento = 0;

		if (noches > 7)
			descuento += 10;

		if (habitual)
			descuento += 5;

		if (anticipacion > 60)
			descuento += 8;

		if (descuento > 20)
			descuento = 20;

		total = total - total * descuento / 100;

		System.out.println(total);
	}
}