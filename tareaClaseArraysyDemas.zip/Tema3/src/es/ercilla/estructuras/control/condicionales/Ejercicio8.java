package es.ercilla.estructuras.control.condicionales;

public class Ejercicio8 {

	public static void main(String[] args) {

		int a = 9;
		int b = 9;
		int c = 17;

		if (a + b <= c || a + c <= b || b + c <= a) {

			System.out.println("NO EXISTE");

		} else {

			if (a == b && b == c)
				System.out.println("EQUILATERO");
			else if (a == b || a == c || b == c)
				System.out.println("ISOSCELES");
			else
				System.out.println("ESCALENO");

			if (a * a + b * b == c * c)
				System.out.println("RECTANGULO");
		}
	}
}