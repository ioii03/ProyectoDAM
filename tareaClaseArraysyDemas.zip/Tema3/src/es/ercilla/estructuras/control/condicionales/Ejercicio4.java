package es.ercilla.estructuras.control.condicionales;

public class Ejercicio4 {

	public static void main(String[] args) {

		int edad = 23;
		int carnet = 4;
		int accidentes = 1;
		int potencia = 230;

		boolean garaje = true;

		int riesgo = 2;

		if (carnet < 2) {
			riesgo = 3;
		}

		if (accidentes > 2) {
			riesgo = 4;
		}

		if (edad < 25 && potencia > 200) {
			riesgo = 4;
		}

		if (garaje && riesgo > 1) {
			riesgo--;
		}

		System.out.println("Riesgo: " + riesgo);
	}
}