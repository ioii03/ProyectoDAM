package es.ercilla.estructuras.control.condicionales;

public class Ejercicio5 {

	public static void main(String[] args) {

		double examen1 = 7;
		double examen2 = 8;
		double practicas = 9;
		double proyecto = 4.5;

		int asistencia = 92;

		double examenes = (examen1 + examen2) / 2;

		double nota = examenes * 0.5 + practicas * 0.2 + proyecto * 0.3;

		if (asistencia < 70) {

			System.out.println("SUSPENSO");

		} else if (proyecto < 5) {

			System.out.println("PROYECTO NO SUPERADO");

		} else if (nota >= 5) {

			System.out.println("APROBADO");

		} else {

			System.out.println("SUSPENSO");
		}

		System.out.println(nota);
	}
}
