package es.ercilla.estructuras.control.condicionales;

public class Ejercicio10 {

	public static void main(String[] args) {

		double precio = 780;

		boolean premium = true;
		boolean codigo = true;
		boolean urgente = true;

		double descuento = 0;

		if (premium)
			descuento += 5;

		if (codigo)
			descuento += 10;

		if (descuento > 12)
			descuento = 12;

		precio -= precio * descuento / 100;

		if (urgente && precio <= 700)
			precio += 25;

		System.out.println(precio);
	}
}