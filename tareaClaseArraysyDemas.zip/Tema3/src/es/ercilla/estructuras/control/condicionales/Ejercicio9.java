package es.ercilla.estructuras.control.condicionales;

public class Ejercicio9 {

	public static void main(String[] args) {

		double salario = 1800;
		int antiguedad = 12;
		int productividad = 92;
		int faltas = 3;

		double bonus = 0;

		if (antiguedad > 10)
			bonus += 10;

		if (productividad >= 90 && faltas <= 2)
			bonus += 8;

		salario = salario + salario * bonus / 100;

		System.out.println(bonus);
		System.out.println(salario);
	}
}
