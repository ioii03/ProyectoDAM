package es.ercilla.estructuras.control.condicionales;

public class Ejercicio3 {

	public static void main(String[] args) {

		double nota = 7.4;
		int edad = 34;
		int experiencia = 3;
		boolean titulo = true;

		if (!titulo) {

			System.out.println("EXCLUIDO");

		} else if (nota >= 8) {

			System.out.println("ADMITIDO");

		} else if (edad > 30 && experiencia >= 5 && nota >= 5) {

			System.out.println("ADMITIDO");

		} else if (nota >= 6 && experiencia >= 2) {

			System.out.println("ADMITIDO");

		} else {

			System.out.println("LISTA DE ESPERA");
		}
	}
}
