package es.ercilla.estructuras.control.bucles;

public class Ejercicio42 {

	public static void main(String[] args) {

		int opcion = 2;

		switch (opcion) {

		case 1:
			System.out.println("Nueva partida");
			break;

		case 2:
			System.out.println("Cargar partida");

		case 3:
			System.out.println("Configuración");
			break;

		case 4:
			System.out.println("Créditos");

		default:
			System.out.println("Fin");
		}
	}
}