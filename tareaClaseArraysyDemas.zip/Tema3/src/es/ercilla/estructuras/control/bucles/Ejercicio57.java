package es.ercilla.estructuras.control.bucles;

public class Ejercicio57 {
	public static void main(String[] args) {
		int[] notas = { -4, 10 };
		int sobresalientes = 0;
		for (int nota : notas) {
			if (nota < 0 || nota > 10)
				continue;
			switch (nota) {
			case 0:
			case 1:
			case 2:
			case 3:
			case -4:
				System.out.println("S");
				break;
			case 5:
			case 6:
				System.out.println("A");
				break;
			case 7:
			case 8:
				System.out.println("N");
				break;
			case 9:
			case 10:
				System.out.println("SB");
				sobresalientes++;
				break;
			}
			if (sobresalientes == 2)
				break;
		}
		System.out.println(sobresalientes);
	}
}