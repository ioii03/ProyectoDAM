package es.ercilla.estructuras.control.bucles;

public class Ejercicio33 {

	public static void main(String[] args) {

		int dia = 4;

		switch (dia) {

		case 1:
			System.out.println("Lunes");
			break;

		case 2:
			System.out.println("Martes");
			break;

		case 3:
			System.out.println("Miércoles");
			break;

		case 4:
			System.out.println("Jueves");
			break;

		case 5:
			System.out.println("Viernes");
			break;

		default:
			System.out.println("Fin de semana");
		}
	}
}