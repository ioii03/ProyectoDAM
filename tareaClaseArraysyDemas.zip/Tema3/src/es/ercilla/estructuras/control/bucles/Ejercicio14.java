package es.ercilla.estructuras.control.bucles;

public class Ejercicio14 {

	public static void main(String[] args) {

		double deposito = 5000;
		int horas = 0;

		while (deposito >= 1000) {

			deposito -= deposito * 0.07;
			horas++;
		}

		System.out.println(horas);
		System.out.println(deposito);
	}
}