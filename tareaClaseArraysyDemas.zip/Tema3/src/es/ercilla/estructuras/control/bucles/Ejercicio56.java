package es.ercilla.estructuras.control.bucles;

public class Ejercicio56 {

	public static double descuento(double importe) {

		if (importe < 100)
			return 0;

		if (importe < 500)
			return 5;

		if (importe < 1000)
			return 10;

		return 15;
	}

	public static void main(String[] args) {

		double[] pedidos = { 250, -20, 850, 120, 1700, 3000, 90 };

		double facturacion = 0;

		for (double pedido : pedidos) {

			if (pedido < 0)
				continue;

			double porcentaje = descuento(pedido);

			pedido -= pedido * porcentaje / 100;

			facturacion += pedido;

			System.out.println(facturacion);

			if (facturacion > 4000)
				break;
		}
	}
}