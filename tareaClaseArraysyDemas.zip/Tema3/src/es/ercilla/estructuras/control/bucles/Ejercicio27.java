package es.ercilla.estructuras.control.bucles;

public class Ejercicio27 {

	public static void main(String[] args) {

		double saldo = 100;

		double[] precios = { 20, 35, 15, 40 };

		int i = 0;

		do {

			if (precios[i] <= saldo) {

				saldo -= precios[i];

				System.out.println("Compra: " + precios[i]);

			} else {

				System.out.println("SIN SALDO");
			}

			i++;

		} while (i < precios.length && saldo > 0);

		System.out.println(saldo);
	}
}