package es.ercilla.estructuras.control.bucles;

public class Ejercicio3 {

	public static void main(String[] args) {

		int numero = 742958;
		int pares = 0;
		int impares = 0;

		for (; numero > 0; numero /= 10) {

			int digito = numero % 10;

			if (digito % 2 == 0)
				pares++;
			else
				impares++;
		}

		System.out.println(pares);
		System.out.println(impares);
	}
}