package es.ercilla.estructuras.control.bucles;

public class Ejercicio4 {

	public static void main(String[] args) {

		int numero = 2;
		int suma = 0;

		for (int i = 1; i <= 8; i++) {

			System.out.println(numero);

			suma += numero;

			numero = numero * 2 + 1;
		}

		System.out.println("Suma: " + suma);
	}
}