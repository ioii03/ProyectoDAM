package es.ercilla.estructuras.control.bucles;

public class Ejercicio41 {

	public static void main(String[] args) {

		int opcion = 2;

		switch (opcion) {

		case 1:
			System.out.println("A");

		case 2:
			System.out.println("B");

		case 3:
			System.out.println("C");

		default:
			System.out.println("D");
		}
	}
}