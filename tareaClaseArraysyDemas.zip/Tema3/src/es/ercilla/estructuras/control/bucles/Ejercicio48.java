package es.ercilla.estructuras.control.bucles;

public class Ejercicio48 {

	public static boolean esPrimo(int numero) {

		for (int i = 2; i < numero; i++) {

			if (numero % i == 0)
				return false;
		}

		return true;
	}

	public static void main(String[] args) {

		System.out.println(esPrimo(21));
		System.out.println(esPrimo(23));
	}
}