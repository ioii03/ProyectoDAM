package es.ercilla.estructuras.control.bucles;

public class Ejercicio17 {
	public static void main(String[] args) {
		double deuda = 12000;
		double pago = 500;
		int meses = 0;
		while (deuda > 0) {
			deuda -= pago;
			pago *= 1.05;
			meses++;
		}
		System.out.println(meses);
		System.out.println(deuda);
	}
}