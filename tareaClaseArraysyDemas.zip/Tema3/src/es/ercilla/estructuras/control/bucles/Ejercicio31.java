package es.ercilla.estructuras.control.bucles;

public class Ejercicio31 {

	public static void main(String[] args) {

		int puntos = 100;

		int[] jugadas = { 20, -30, 50, -80, 10 };

		int i = 0;

		do {

			puntos += jugadas[i];

			System.out.println(puntos);

			i++;

		} while (puntos > 0 && i < jugadas.length);

		System.out.println("FIN");
	}
}