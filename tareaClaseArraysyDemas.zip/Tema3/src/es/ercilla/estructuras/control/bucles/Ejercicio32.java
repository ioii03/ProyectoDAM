package es.ercilla.estructuras.control.bucles;

public class Ejercicio32 {

	public static void main(String[] args) {

		int saldo = 800;

		int[] cantidades = { 0, -20, 950, 250 };

		int i = 0;

		do {

			System.out.println("Cantidad: " + cantidades[i]);

			i++;

		} while (cantidades[i - 1] <= 0 || cantidades[i - 1] > saldo);

		saldo -= cantidades[i - 1];

		System.out.println(saldo);
	}
}