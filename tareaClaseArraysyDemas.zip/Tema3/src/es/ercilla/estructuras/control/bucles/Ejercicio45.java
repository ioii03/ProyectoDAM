package es.ercilla.estructuras.control.bucles;

public class Ejercicio45 {

	public static void main(String[] args) {

		int[] notas = { 7, 8, -1, 5, 12, 9, 4 };

		int suma = 0;
		int validas = 0;

		for (int nota : notas) {

			if (nota < 0 || nota > 10)
				continue;

			suma += nota;
			validas++;
		}

		System.out.println(suma);
		System.out.println(validas);
		System.out.println((double) suma / validas);
	}
}