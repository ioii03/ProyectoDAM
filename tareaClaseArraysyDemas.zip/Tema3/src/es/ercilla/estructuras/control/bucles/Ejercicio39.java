package es.ercilla.estructuras.control.bucles;

public class Ejercicio39 {

	public static void main(String[] args) {

		char operacion = '/';

		double a = 20;
		double b = 4;

		switch (operacion) {

		case '+':
			System.out.println(a + b);
			break;

		case '-':
			System.out.println(a - b);
			break;

		case '*':
			System.out.println(a * b);
			break;

		case '/':

			if (b != 0)
				System.out.println(a / b);
			else
				System.out.println("ERROR");

			break;
		}
	}
}