package es.ercilla.estructuras.control.bucles;

public class Ejercicio13 {

	public static void main(String[] args) {

		double dinero = 2000;
		int meses = 0;

		while (dinero <= 3000) {

			dinero *= 1.02;
			meses++;
		}

		System.out.println(meses);
		System.out.println(dinero);
	}
}