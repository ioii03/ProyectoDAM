package es.ercilla.estructuras.control.bucles;

public class Ejercicio52 {

	public static void main(String[] args) {

		for (int i = 10; i <= 100; i++) {

			if (i % 2 == 0)
				continue;

			System.out.println(i);

			if (i % 17 == 0)
				break;
		}

		System.out.println("FIN");
	}
}