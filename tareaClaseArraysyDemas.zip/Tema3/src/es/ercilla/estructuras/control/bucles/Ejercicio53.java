package es.ercilla.estructuras.control.bucles;

public class Ejercicio53 {

	public static void main(String[] args) {

		double saldo = 20;

		int[] opciones = { 2, 3, 5, 4, 0 };

		for (int opcion : opciones) {

			double precio = 0;

			switch (opcion) {

			case 0:
				System.out.println("SALIR");
				break;

			case 1:
				precio = 1;
				break;

			case 2:
				precio = 1.5;
				break;

			case 3:
				precio = 4;
				break;

			case 4:
				precio = 2;
				break;

			case 5:
				precio = 7;
				break;
			}

			if (opcion == 0)
				break;

			if (precio > saldo) {
				System.out.println("Saldo insuficiente");
				continue;
			}

			saldo -= precio;

			System.out.println(saldo);
		}
	}
}