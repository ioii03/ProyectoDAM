package es.ercilla.estructuras.control.bucles;

public class Ejercicio12 {

    public static void main(String[] args) {

        int numero = 53827491;

        int suma = 0;
        int mayores = 0;

        while (numero > 0) {

            int digito = numero % 10;

            suma += digito;

            if (digito > 5)
                mayores++;

            numero /= 10;
        }

        System.out.println(suma);
        System.out.println(mayores);
    }
}