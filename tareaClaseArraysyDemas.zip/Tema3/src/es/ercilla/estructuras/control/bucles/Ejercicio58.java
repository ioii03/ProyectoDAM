package es.ercilla.estructuras.control.bucles;

public class Ejercicio58 {

	public static String comprobar(int intento, int secreto) {

		if (intento < secreto)
			return "mayor";

		if (intento > secreto)
			return "menor";

		return "correcto";
	}

	public static void main(String[] args) {

		int secreto = 73;

		int[] intentos = { 40, 90, -2, 65, 80, 73 };

		int validos = 0;

		for (int intento : intentos) {

			if (intento < 1 || intento > 100)
				continue;

			validos++;

			String resultado = comprobar(intento, secreto);

			System.out.println(resultado);

			if (resultado.equals("correcto"))
				break;

			if (validos == 5)
				break;
		}

		System.out.println(validos);
	}
}