package es.ercilla.estructuras.control.bucles;

public class Ejercicio2 {

	public static void main(String[] args) {

		int contador = 0;

		for (int i = 100; i <= 250; i++) {

			int centenas = i / 100;
			int decenas = i / 10 % 10;
			int unidades = i % 10;

			if (centenas + decenas + unidades == 12) {

				System.out.println(i);
				contador++;
			}
		}

		System.out.println("Total: " + contador);
	}
}