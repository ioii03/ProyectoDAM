package es.ercilla.estructuras.control.bucles;

public class Ejercicio15 {

	public static void main(String[] args) {

		int numero = 840;
		int contador = 0;

		while (numero % 2 == 0) {

			numero /= 2;
			contador++;
		}

		System.out.println(numero);
		System.out.println(contador);
	}
}