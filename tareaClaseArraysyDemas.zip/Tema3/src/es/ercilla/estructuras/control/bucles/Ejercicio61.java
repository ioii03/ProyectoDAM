package es.ercilla.estructuras.control.bucles;

public class Ejercicio61 {

	public static int plazas(String tipo) {

		switch (tipo) {

		case "moto":
			return 1;

		case "coche":
			return 2;

		case "camion":
			return 3;

		default:
			return 5;
		}
	}

	public static void main(String[] args) {

		int libres = 10;

		String[] vehiculos = { "coche", "moto", "camion", "coche", "camion", "moto", "autobus" };

		for (String vehiculo : vehiculos) {

			int necesita = plazas(vehiculo);

			if (necesita > libres) {

				System.out.println("RECHAZADO");

				continue;
			}

			libres -= necesita;

			System.out.println(libres);

			if (libres == 0)
				break;
		}
	}
}