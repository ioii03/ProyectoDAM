package es.ercilla.estructuras.control.bucles;

public class Ejercicio37 {

	public static void main(String[] args) {

		int nivel = 2;

		switch (nivel) {

		case 3:
			System.out.println("Administración");

		case 2:
			System.out.println("Escritura");

		case 1:
			System.out.println("Lectura");
		}
	}
}