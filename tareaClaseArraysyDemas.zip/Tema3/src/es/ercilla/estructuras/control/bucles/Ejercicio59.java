package es.ercilla.estructuras.control.bucles;

public class Ejercicio59 {

	public static boolean comprobar(String usuario, String clave) {

		return usuario.equals("dam") && clave.equals("java21");
	}

	public static void main(String[] args) {

		String[] usuarios = { "admin", "", "dam", "dam" };

		String[] claves = { "123", "abc", "1234", "java21" };

		int errores = 0;

		for (int i = 0; i < usuarios.length; i++) {

			if (usuarios[i].isEmpty())
				continue;

			if (comprobar(usuarios[i], claves[i])) {

				System.out.println("OK");
				break;

			} else {

				errores++;
			}

			if (errores == 3) {

				System.out.println("BLOQUEADO");

				break;
			}
		}

		System.out.println(errores);
	}
}