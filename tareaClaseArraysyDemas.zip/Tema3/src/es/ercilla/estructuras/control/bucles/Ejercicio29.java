package es.ercilla.estructuras.control.bucles;

public class Ejercicio29 {

	public static void main(String[] args) {

		int bateria = 8;
		int ciclos = 0;

		do {

			bateria += 13;

			if (bateria > 100)
				bateria = 100;

			ciclos++;

			System.out.println(bateria);

		} while (bateria < 80);

		System.out.println(ciclos);
	}
}