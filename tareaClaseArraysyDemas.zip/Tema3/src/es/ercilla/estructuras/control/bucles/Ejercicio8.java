package es.ercilla.estructuras.control.bucles;

public class Ejercicio8 {

	public static void main(String[] args) {

		for (int numero = 1; numero <= 5; numero++) {

			int factorial = 1;

			for (int j = 1; j <= numero; j++)
				factorial *= j;

			System.out.println(numero + " " + numero * numero + " " + numero * numero * numero + " " + factorial);
		}
	}
}