package es.ercilla.estructuras.control.bucles;

public class Ejercicio54 {

	public static void main(String[] args) {

		int[] temperaturas = { 18, 25, 31, -100, 36, 42, 27, 55 };

		int normales = 0;
		int altas = 0;
		int criticas = 0;

		for (int t : temperaturas) {

			if (t == -100)
				continue;

			if (t >= 50) {

				System.out.println("EMERGENCIA");

				break;
			}

			if (t < 20) {

				System.out.println("BAJA");

			} else if (t <= 30) {

				normales++;

			} else if (t < 40) {

				altas++;

			} else {

				criticas++;
			}
		}

		System.out.println(normales);
		System.out.println(altas);
		System.out.println(criticas);
	}
}