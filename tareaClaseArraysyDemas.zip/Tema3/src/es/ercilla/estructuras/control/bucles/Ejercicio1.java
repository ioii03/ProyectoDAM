package es.ercilla.estructuras.control.bucles;

public class Ejercicio1 {

    public static void main(String[] args) {

        int contador = 0;
        int suma = 0;

        for (int i = 100; i <= 150; i++) {

            if (i % 3 == 0 &&
                i % 5 == 0 &&
                i % 7 != 0) {

                contador++;
                suma += i;
            }
        }

        System.out.println(contador);
        System.out.println(suma);
    }
}