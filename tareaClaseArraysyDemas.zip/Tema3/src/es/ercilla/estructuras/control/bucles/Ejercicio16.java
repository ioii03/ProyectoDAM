package es.ercilla.estructuras.control.bucles;

public class Ejercicio16 {

    public static void main(String[] args) {

        int corredor1 = 100;
        int corredor2 = 0;
        int segundos = 0;

        while (corredor2 < corredor1) {

            corredor1 += 7;
            corredor2 += 9;

            segundos++;
        }

        System.out.println(segundos);
        System.out.println(corredor1);
        System.out.println(corredor2);
    }
}