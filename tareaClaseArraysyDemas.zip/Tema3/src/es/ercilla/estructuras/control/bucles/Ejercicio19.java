package es.ercilla.estructuras.control.bucles;

public class Ejercicio19 {

	public static void main(String[] args) {

		int numero = 1234321;
		int copia = numero;
		int inverso = 0;

		while (copia > 0) {

			inverso = inverso * 10 + copia % 10;

			copia /= 10;
		}

		if (numero == inverso)
			System.out.println("CAPICUA");
		else
			System.out.println("NO CAPICUA");
	}
}