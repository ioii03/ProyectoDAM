package es.ercilla.estructuras.control.bucles;

public class Ejercicio30 {

	public static void main(String[] args) {

		int ocupacion = 3;

		int[] operaciones = { 1, 1, 1, 2, 1, 0 };

		int i = 0;

		do {

			int opcion = operaciones[i];

			if (opcion == 1) {

				if (ocupacion < 5)
					ocupacion++;

			} else if (opcion == 2) {

				if (ocupacion > 0)
					ocupacion--;
			}

			System.out.println(ocupacion);

			i++;

		} while (operaciones[i - 1] != 0);
	}
}