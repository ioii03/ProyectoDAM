package es.ercilla.estructuras.control.bucles;

public class Ejercicio34 {

	public static void main(String[] args) {

		int mes = 2;
		int anio = 2028;

		int dias;

		switch (mes) {

		case 4:
		case 6:
		case 9:
		case 11:
			dias = 30;
			break;

		case 2:

			if (anio % 400 == 0 || (anio % 4 == 0 && anio % 100 != 0))
				dias = 29;
			else
				dias = 28;

			break;

		default:
			dias = 31;
		}

		System.out.println(dias);
	}
}