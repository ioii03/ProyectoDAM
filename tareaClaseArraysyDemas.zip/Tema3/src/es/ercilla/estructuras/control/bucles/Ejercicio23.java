package es.ercilla.estructuras.control.bucles;

public class Ejercicio23 {

	public static void main(String[] args) {

		double saldo = 1200;

		int[] operaciones = { 1, 2, 3, 2, 0 };
		double[] cantidades = { 0, 300, 150, 1500, 0 };

		int i = 0;

		do {

			if (operaciones[i] == 1) {

				System.out.println(saldo);

			} else if (operaciones[i] == 2) {

				if (cantidades[i] <= saldo)
					saldo -= cantidades[i];
				else
					System.out.println("ERROR");

			} else if (operaciones[i] == 3) {

				saldo += cantidades[i];
			}

			i++;

		} while (i < operaciones.length && operaciones[i - 1] != 0);

		System.out.println(saldo);
	}
}