package es.ercilla.estructuras.control.bucles;

public class Ejercicio49 {

	public static int mayor(int a, int b, int c) {

		if (a >= b && a >= c)
			return a;

		if (b >= a && b >= c)
			return b;

		return c;
	}

	public static void main(String[] args) {

		int resultado = mayor(14, 27, 19);

		System.out.println(resultado);
	}
}