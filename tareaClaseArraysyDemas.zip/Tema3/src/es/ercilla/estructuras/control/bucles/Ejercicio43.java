package es.ercilla.estructuras.control.bucles;

public class Ejercicio43 {

	public static void main(String[] args) {

		int[] numeros = { 4, 8, 12, 17, 23, 34, 51 };

		for (int n : numeros) {

			System.out.println("Analizando " + n);

			if (n % 17 == 0) {

				System.out.println("Encontrado");

				break;
			}
		}

		System.out.println("FIN");
	}
}