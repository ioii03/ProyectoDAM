package es.ercilla.estructuras.control.bucles;

public class Ejercicio20 {

	public static void main(String[] args) {

		int numero = 27;
		int pasos = 0;

		while (numero != 1) {

			if (numero % 2 == 0)
				numero /= 2;
			else
				numero = numero * 3 + 1;

			pasos++;

			System.out.print(numero + " ");
		}

		System.out.println();
		System.out.println(pasos);
	}
}