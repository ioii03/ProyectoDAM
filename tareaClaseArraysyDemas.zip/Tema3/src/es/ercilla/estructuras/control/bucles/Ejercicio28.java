package es.ercilla.estructuras.control.bucles;

public class Ejercicio28 {

	public static void main(String[] args) {

		int[] notas = { 15, -3, 12, 8 };

		int i = 0;

		do {

			System.out.println(notas[i]);

			i++;

		} while (notas[i - 1] < 0 || notas[i - 1] > 10);

		System.out.println("Intentos: " + i);
	}
}