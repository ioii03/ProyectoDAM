package es.ercilla.estructuras.control.bucles;

public class Ejercicio7 {

	public static void main(String[] args) {

		double saldo = 5000;

		for (int mes = 1; mes <= 3; mes++) {

			saldo = saldo * 1.015;

			if (mes % 3 == 0)
				saldo -= 120;

			System.out.println(mes + ": " + saldo);
		}
	}
}