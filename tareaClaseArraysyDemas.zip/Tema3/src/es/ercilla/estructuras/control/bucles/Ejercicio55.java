package es.ercilla.estructuras.control.bucles;

public class Ejercicio55 {

	public static void main(String[] args) {

		double saldo = 1500;

		int[] operaciones = { 1, 2, 2, 3, 2, 0 };

		double[] cantidades = { 0, 400, 1300, 500, 700, 0 };

		int i = 0;

		while (i < operaciones.length) {

			switch (operaciones[i]) {

			case 0:
				System.out.println("SALIR");
				return;

			case 1:
				System.out.println(saldo);
				break;

			case 2:

				if (cantidades[i] > saldo) {

					System.out.println("DENEGADO");

					i++;

					continue;
				}

				saldo -= cantidades[i];

				break;

			case 3:

				saldo += cantidades[i];

				break;
			}

			System.out.println("Saldo: " + saldo);

			i++;
		}
	}
}