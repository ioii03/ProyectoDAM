package es.ercilla.estructuras.control.bucles;

public class Ejercicio10 {

	public static void main(String[] args) {

		int n = 5;

		for (int fila = n; fila >= 1; fila--) {

			for (int columna = 1; columna <= fila; columna++) {

				System.out.print("*");
			}

			System.out.println();
		}

		for (int fila = 2; fila <= n; fila++) {

			for (int columna = 1; columna <= fila; columna++) {

				System.out.print("*");
			}

			System.out.println();
		}
	}
}