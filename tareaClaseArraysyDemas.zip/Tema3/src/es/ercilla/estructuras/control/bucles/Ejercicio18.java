package es.ercilla.estructuras.control.bucles;

public class Ejercicio18 {

	public static void main(String[] args) {

		int a = 1071;
		int b = 462;

		while (b != 0) {

			int resto = a % b;

			a = b;
			b = resto;

			System.out.println(a + " " + b);
		}

		System.out.println("MCD: " + a);
	}
}