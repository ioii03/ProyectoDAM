package es.ercilla.estructuras.control.bucles;

public class Ejercicio40 {

	public static void main(String[] args) {

		int trimestre = 3;

		switch (trimestre) {

		case 1:
			System.out.println("Enero Febrero Marzo");
			break;

		case 2:
			System.out.println("Abril Mayo Junio");
			break;

		case 3:
			System.out.println("Julio Agosto Septiembre");
			break;

		case 4:
			System.out.println("Octubre Noviembre Diciembre");
		}
	}
}