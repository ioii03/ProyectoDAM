package es.ercilla.estructuras.control.bucles;

public class Ejercicio6 {

	public static void main(String[] args) {

		int contador = 0;

		for (int a = 1; a <= 20; a++) {

			for (int b = 1; b <= 20; b++) {

				if (a + b == 20 && (a * b) % 6 == 0) {

					System.out.println(a + " " + b);
					contador++;
				}
			}
		}

		System.out.println(contador);
	}
}