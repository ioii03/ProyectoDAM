package es.ercilla.estructuras.control.bucles;

public class Ejercicio24 {
	public static void main(String[] args) {
		int secreto = 47;
		int[] intentos = { 20, 70, 40, 49, 47 };
		int i = 0;
		do {
			int intento = intentos[i];
			if (intento < secreto)
				System.out.println("MAYOR");
			else if (intento > secreto)
				System.out.println("MENOR");
			else
				System.out.println("ACERTADO");
			i++;
		} while (intentos[i - 1] != secreto);
	}
}