package es.ercilla.estructuras.control.bucles;

public class Ejercicio11 {
	public static void main(String[] args) {
		int numero = 987654;
		int inverso = 0;
		while (numero > 0) {
			int digito = numero % 10;
			inverso = inverso * 10 + digito;
			numero /= 10;
		}
		System.out.println(inverso);
	}
}