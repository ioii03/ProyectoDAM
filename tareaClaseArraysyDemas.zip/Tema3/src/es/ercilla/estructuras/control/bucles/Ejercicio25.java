package es.ercilla.estructuras.control.bucles;

public class Ejercicio25 {

	public static void main(String[] args) {

		int pin = 2580;

		int[] intentos = { 1234, 1111, 2580 };

		int i = 0;

		do {

			if (intentos[i] == pin)
				System.out.println("CORRECTO");
			else
				System.out.println("INCORRECTO");

			i++;

		} while (i < 3 && intentos[i - 1] != pin);

		System.out.println("Intentos: " + i);
	}
}