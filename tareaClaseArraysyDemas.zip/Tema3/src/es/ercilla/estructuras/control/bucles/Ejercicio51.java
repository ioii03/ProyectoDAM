package es.ercilla.estructuras.control.bucles;

public class Ejercicio51 {

	public static boolean login(String usuario, String password) {

		if (usuario == null || password == null)
			return false;

		if (usuario.equals("dam") && password.equals("java21"))
			return true;

		return false;
	}

	public static void main(String[] args) {

		System.out.println(login("dam", "1234"));

		System.out.println(login("dam", "java21"));
	}
}