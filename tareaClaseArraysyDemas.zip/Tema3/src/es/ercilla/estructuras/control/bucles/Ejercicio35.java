package es.ercilla.estructuras.control.bucles;

public class Ejercicio35 {

	public static void main(String[] args) {

		char categoria = 'B';
		int bonus;

		switch (categoria) {

		case 'A':
			bonus = 20;
			break;

		case 'B':
			bonus = 15;
			break;

		case 'C':
			bonus = 10;
			break;

		default:
			bonus = 5;
		}

		System.out.println(bonus);
	}
}