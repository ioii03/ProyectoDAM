package es.ercilla.estructuras.control.bucles;

public class Ejercicio5 {

	public static void main(String[] args) {

		for (int numero = 2; numero <= 30; numero++) {

			boolean primo = true;

			for (int divisor = 2; divisor < numero; divisor++) {

				if (numero % divisor == 0)
					primo = false;
			}

			if (primo)
				System.out.print(numero + " ");
		}
	}
}