package es.ercilla.estructuras.control.bucles;

public class Ejercicio50 {

	public static double descuento(double compra) {

		if (compra < 100)
			return 0;

		if (compra < 500)
			return 5;

		if (compra < 1000)
			return 10;

		return 15;
	}

	public static void main(String[] args) {

		System.out.println(descuento(450));

		System.out.println(descuento(1200));
	}
}