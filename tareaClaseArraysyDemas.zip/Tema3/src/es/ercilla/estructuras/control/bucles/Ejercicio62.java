package es.ercilla.estructuras.control.bucles;

public class Ejercicio62 {
	public static int categoria(double compra) {
		if (compra < 100)
			return 1;
		if (compra < 500)
			return 2;
		if (compra < 1000)
			return 3;
		return 4;
	}

	public static double descuento(int categoria) {
		switch (categoria) {
		case 1:
			return 0;
		case 2:
			return 5;
		case 3:
			return 10;
		case 4:
			return 15;
		default:
			return 0;
		}
	}

	public static void main(String[] args) {
		double[] compras = { 80, 250, -30, 520, 1100, 75, 1600, 400 };
		double facturacion = 0;
		int basicos = 0;
		int estandar = 0;
		int premium = 0;
		int vip = 0;
		for (double compra : compras) {
			if (compra < 0) {
				System.out.println("Compra incorrecta");
				continue;
			}
			int categoria = categoria(compra);
			double porcentaje = descuento(categoria);
			switch (categoria) {
			case 1:
				basicos++;
				break;
			case 2:
				estandar++;
				break;
			case 3:
				premium++;
				break;
			case 4:
				vip++;
				break;
			}
			double precioFinal = compra - compra * porcentaje / 100;
			facturacion += precioFinal;
			System.out.println("Compra: " + compra);
			System.out.println("Categoría: " + categoria);
			System.out.println("Descuento: " + porcentaje);
			System.out.println("Precio final: " + precioFinal);
			System.out.println("Acumulado: " + facturacion);
			if (facturacion > 3500) {
				System.out.println("Límite alcanzado");
				break;
			}
		}
		System.out.println("Facturación: " + facturacion);
		System.out.println("Básicos: " + basicos);
		System.out.println("Estándar: " + estandar);
		System.out.println("Premium: " + premium);
		System.out.println("VIP: " + vip);
	}
}