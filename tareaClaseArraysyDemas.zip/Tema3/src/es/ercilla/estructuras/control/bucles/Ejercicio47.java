package es.ercilla.estructuras.control.bucles;

public class Ejercicio47 {

	public static void main(String[] args) {

		for (int numero = 101; numero <= 120; numero++) {

			boolean primo = true;

			for (int divisor = 2; divisor < numero; divisor++) {

				if (numero % divisor == 0) {
					primo = false;
					break;
				}
			}

			if (primo) {

				System.out.println(numero);
				break;
			}
		}
	}
}