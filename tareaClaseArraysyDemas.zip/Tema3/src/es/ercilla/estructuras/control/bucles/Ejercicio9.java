package es.ercilla.estructuras.control.bucles;

public class Ejercicio9 {

	public static void main(String[] args) {

		int encontrados = 0;

		for (int numero = 1000; numero <= 1500; numero++) {

			int primero = numero / 1000;
			int ultimo = numero % 10;

			int segundo = numero / 100 % 10;
			int tercero = numero / 10 % 10;

			if (primero == ultimo && segundo + tercero == 10) {

				System.out.println(numero);
				encontrados++;
			}
		}

		System.out.println(encontrados);
	}
}