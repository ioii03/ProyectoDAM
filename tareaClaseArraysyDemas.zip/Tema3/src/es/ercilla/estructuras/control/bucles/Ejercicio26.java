package es.ercilla.estructuras.control.bucles;

public class Ejercicio26 {

	public static void main(String[] args) {

		int[] operaciones = { 1, 3, 2, 0 };

		int a = 20;
		int b = 5;

		int i = 0;

		do {

			int opcion = operaciones[i];

			if (opcion == 1)
				System.out.println(a + b);
			else if (opcion == 2)
				System.out.println(a - b);
			else if (opcion == 3)
				System.out.println(a * b);

			i++;

		} while (operaciones[i - 1] != 0);
	}
}