package es.ercilla.estructuras.control.bucles;

public class Ejercicio44 {

	public static void main(String[] args) {

		int[] numeros = { 12, -4, 20, -8, 7, 0, 13 };

		int suma = 0;

		for (int n : numeros) {

			if (n < 0)
				continue;

			suma += n;

			System.out.println(n);
		}

		System.out.println("Suma: " + suma);
	}
}