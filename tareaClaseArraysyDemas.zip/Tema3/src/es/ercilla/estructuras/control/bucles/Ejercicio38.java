package es.ercilla.estructuras.control.bucles;

public class Ejercicio38 {

	public static void main(String[] args) {

		char categoria = 'B';
		int bonus = 0;

		switch (categoria) {

		case 'A':
			bonus += 500;

		case 'B':
			bonus += 300;

		case 'C':
			bonus += 100;
		}

		System.out.println(bonus);
	}
}