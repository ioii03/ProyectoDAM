package es.ercilla.estructuras.control.bucles;
public class Ejercicio60 {
	public static double precio(int categoria) {
		switch (categoria) {
		case 1:
			return 0.15;
		case 2:
			return 0.20;
		case 3:
			return 0.25;
		default:
			return 0.30;
		}
	}
	public static void main(String[] args) {
		int[] consumos = { 120, 1500, 720};
		for (int consumo : consumos) {
			if (consumo < 0)
				continue;
			if (consumo > 1000) {
				System.out.println("ALERTA");
				break;
			}
			int categoria;
			if (consumo <= 200)
				categoria = 1;
			else if (consumo <= 500)
				categoria = 2;
			else if (consumo <= 800)
				categoria = 3;
			else
				categoria = 4;
			System.out.println(consumo * precio(categoria));
		}
	}
}