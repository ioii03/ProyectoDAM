package es.ercilla.condicionales;

public class Condicionales {

	public void primero() {
		int numero = 8;
		if (numero > 0) {
			System.out.println("El número es positivo");
		}
	}

	public void segundo() {
		int edad = 17;
		if (edad >= 18) {
			System.out.println("Es mayor de edad");
		} else {
			System.out.println("Es menor de edad");
		}
	}

	public void tercero() {
		int numero = 15;
		if (numero % 2 == 0) {
			System.out.println("El número es par");
		} else {
			System.out.println("El número es impar");
		}
	}

	public void cuarto() {
		String password = "java123";
		if (password.equals("java123")) {
			System.out.println("Acceso permitido");
		} else {
			System.out.println("Contraseña incorrecta");
		}
	}

	public void quinto() {
		double nota = 7.8;
		if (nota < 5) {
			System.out.println("Suspenso");
		} else if (nota < 7) {
			System.out.println("Aprobado");
		} else if (nota < 9) {
			System.out.println("Notable");
		} else {
			System.out.println("Sobresaliente");
		}
	}

	public void sexto() {
		int numero1 = 25;
		int numero2 = 18;
		if (numero1 > numero2) {
			System.out.println(numero1 + " es mayor");
		} else if (numero2 > numero1) {
			System.out.println(numero2 + " es mayor");
		} else {
			System.out.println("Los dos números son iguales");
		}
	}

	public void septimo() {
		int edad = 14;
		double altura = 1.55;
		if (edad >= 12 && altura >= 1.40) {
			System.out.println("Puede subir a la atracción");
		} else {
			System.out.println("No puede subir a la atracción");
		}
	}

	public void octavo() {
		int edad = 70;
		if (edad < 25 || edad > 65) {
			System.out.println("Tiene descuento");
		} else {
			System.out.println("No tiene descuento");
		}
	}

	public void noveno() {
		double saldo = 800;
		double cantidadRetirar = 500;
		if (cantidadRetirar <= 0) {
			System.out.println("La cantidad debe ser mayor que 0");
		} else if (cantidadRetirar > saldo) {
			System.out.println("Saldo insuficiente");
		} else {
			saldo = saldo - cantidadRetirar;
			System.out.println("Operación realizada");
			System.out.println("Saldo restante: " + saldo);
		}
	}

	public void decimo() {
		double nota = 11;
		if (nota < 0 || nota > 10) {
			System.out.println("Nota incorrecta");
		} else if (nota < 5) {
			System.out.println("Suspenso");
		} else if (nota < 7) {
			System.out.println("Aprobado");
		} else if (nota < 9) {
			System.out.println("Notable");
		} else {
			System.out.println("Sobresaliente");
		}
	}

	public void decimoPrimero() {
		int edad = 68;
		double dinero = 28000;
		double precioVehiculo = 30000;
		if (edad < 18) {
			System.out.println("No puede comprar el vehículo");
		} else {
			if (edad >= 65) {
				precioVehiculo = precioVehiculo * 0.90;
			}
			if (dinero >= precioVehiculo) {
				System.out.println("Puede comprar el vehículo");
				System.out.println("Precio final: " + precioVehiculo);
			} else {
				System.out.println("No dispone de dinero suficiente");
			}
		}
	}

	public void decimoSegundo() {
		int edad = 20;
		double precio = 40;
		double precioFinal;
		if (edad < 12) {
			precioFinal = precio * 0.50;
		} else if (edad <= 25) {
			precioFinal = precio * 0.80;
		} else if (edad > 65) {
			precioFinal = precio * 0.70;
		} else {
			precioFinal = precio;
		}
		System.out.println("Precio original: " + precio);
		System.out.println("Precio final: " + precioFinal);
	}

	public void decimoTercero() {
		String usuario = "admin";
		String password = "1234";
		boolean cuentaBloqueada = false;
		if (cuentaBloqueada) {
			System.out.println("La cuenta está bloqueada");
		} else if (usuario.equals("admin") && password.equals("1234")) {
			System.out.println("Acceso correcto");
		} else {
			System.out.println("Usuario o contraseña incorrectos");
		}
	}

	public void decimoCuarto() {
		int tipoUsuario = 2;
		switch (tipoUsuario) {
		case 1 -> System.out.println("Administrador");
		case 2 -> System.out.println("Profesor");
		case 3 -> System.out.println("Alumno");
		default -> System.out.println("Tipo de usuario incorrecto");
		}
	}

	public void decimoQuinto() {
		int tipoUsuario = 2;
		switch (tipoUsuario) {
		case 1:
			System.out.println("Administrador");
		case 2:
			System.out.println("Profesor");
		case 3:
			System.out.println("Alumno");
		default:
			System.out.println("Tipo de usuario incorrecto");
		}
	}

	public void decimoSexto() {
		int edad = 35;
		double sueldo = 1800;
		boolean tieneDeudas = false;
		if (edad < 18) {
			System.out.println("Préstamo rechazado: menor de edad");
		} else if (sueldo < 1200) {
			System.out.println("Préstamo rechazado: sueldo insuficiente");
		} else if (tieneDeudas) {
			System.out.println("Préstamo rechazado: tiene deudas pendientes");
		} else {
			System.out.println("Préstamo aprobado");
		}
	}

}
