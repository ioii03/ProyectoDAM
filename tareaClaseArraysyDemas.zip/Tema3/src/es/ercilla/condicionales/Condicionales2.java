package es.ercilla.condicionales;

public class Condicionales2 {

	public void ejemplo1() {
		int edad = 35;
		boolean tieneTarjeta = true;
		int nivelSeguridad = 3;
		int hora = 23;
		boolean informatica = true;

		if (!tieneTarjeta) {

			System.out.println("ACCESO DENEGADO: no tiene tarjeta.");

		} else if (edad < 18) {

			System.out.println("ACCESO DENEGADO: menor de edad.");

		} else if (nivelSeguridad < 2) {

			System.out.println("ACCESO DENEGADO: nivel insuficiente.");

		} else if (hora >= 8 && hora <= 20) {

			System.out.println("ACCESO AUTORIZADO.");

		} else if (informatica && nivelSeguridad == 3) {

			System.out.println("ACCESO AUTORIZADO FUERA DE HORARIO.");

		} else {

			System.out.println("ACCESO DENEGADO FUERA DE HORARIO.");
		}
	}

	public void ejemplo2() {
		double precio = 32000;
		String tipo = "ocasion";
		boolean entregaVehiculo = true;
		int antiguedad = 12;
		boolean contado = true;
		int comprasAnteriores = 4;
		double descuento = 0;
		if (tipo.equals("nuevo")) {
			descuento = 3;
		} else if (tipo.equals("ocasion")) {
			descuento = 5;
		}
		if (entregaVehiculo && antiguedad > 10) {
			descuento = descuento + 2;
		}
		if (contado) {
			descuento = descuento + 3;
		}
		if (comprasAnteriores >= 3) {
			descuento = descuento + 4;
		}
		if (tipo.equals("ocasion") && precio > 30000) {
			descuento = descuento + 1;
		}
		if (descuento > 12) {
			descuento = 12;
		}
		if (precio < 10000 && descuento > 7) {
			descuento = 7;
		}
		double importeDescuento = precio * descuento / 100;
		double precioFinal = precio - importeDescuento;

		System.out.println("Precio inicial: " + precio);
		System.out.println("Descuento: " + descuento + "%");
		System.out.println("Descuento en euros: " + importeDescuento);
		System.out.println("Precio final: " + precioFinal);
	}

	public void ejemplo3() {
		double examen1 = 8;
		double examen2 = 6;
		double practicas = 9;
		double proyecto = 8;
		double asistencia = 76;
		double mediaExamenes = (examen1 + examen2) / 2;
		double notaFinal = mediaExamenes * 0.50 + practicas * 0.20 + proyecto * 0.30;
		if (asistencia < 70) {
			notaFinal = 0;
		} else if (asistencia < 80 && notaFinal > 6) {
			notaFinal = 6;
		}
		if ((examen1 == 0 || examen2 == 0 || practicas == 0 || proyecto == 0) && notaFinal > 4) {
			notaFinal = 4;
		}
		System.out.println("Media exámenes: " + mediaExamenes);
		System.out.println("Nota final: " + notaFinal);
		if (asistencia < 70) {
			System.out.println("SUSPENSO POR ASISTENCIA");
		} else if (mediaExamenes < 4) {
			System.out.println("SUSPENSO POR EXÁMENES");
		} else if (proyecto < 5) {
			System.out.println("SUSPENSO POR PROYECTO");
		} else if (notaFinal < 5) {
			System.out.println("SUSPENSO");
		} else if (examen1 >= 9 && examen2 >= 9 && practicas >= 9 && proyecto >= 9) {
			System.out.println("MATRÍCULA PROPUESTA");
		} else if (notaFinal < 7) {
			System.out.println("APROBADO");
		} else if (notaFinal < 9) {
			System.out.println("NOTABLE");
		} else {
			System.out.println("SOBRESALIENTE");
		}
	}

	public void ejemplo4() {
		double saldo = 400;
		double cantidad = 700;
		double limiteDiario = 1000;
		double retiradoHoy = 100;
		String tipoCliente = "premium";
		int hora = 14;
		boolean tieneEfectivo = true;
		boolean premium = tipoCliente.equals("premium");
		if (cantidad <= 0) {
			System.out.println("Cantidad incorrecta.");
		} else if (!tieneEfectivo) {
			System.out.println("Cajero sin efectivo.");
		} else if (retiradoHoy + cantidad > limiteDiario) {
			System.out.println("Límite diario superado.");
		} else if (hora >= 0 && hora < 6 && !premium && cantidad > 300) {
			System.out.println("Superado límite nocturno.");
		} else if (hora >= 0 && hora < 6 && premium && cantidad > 600) {
			System.out.println("Superado límite nocturno premium.");
		} else if (premium && saldo - cantidad >= -500) {
			saldo = saldo - cantidad;
			System.out.println("OPERACIÓN AUTORIZADA");
			System.out.println("Nuevo saldo: " + saldo);
		} else if (!premium && cantidad <= saldo) {
			saldo = saldo - cantidad;
			System.out.println("OPERACIÓN AUTORIZADA");
			System.out.println("Nuevo saldo: " + saldo);
		} else {
			System.out.println("OPERACIÓN DENEGADA");
		}
	}

	public void ejemplo5() {
		String sistema = "servidor";
		int usuarios = 75;
		boolean detenido = true;
		boolean alternativa = true;
		boolean horarioLaboral = true;
		boolean clienteExterno = true;
		int nivel = 1;		
		if (detenido) {
			nivel = 3;
		}
		if (sistema.equals("servidor") && detenido && usuarios > 50) {
			nivel = 4;
		}
		if (usuarios > 100) {
			nivel = 4;
		}
		if (clienteExterno && nivel < 4) {
			nivel++;
		}
		if (alternativa && nivel > 1) {
			nivel--;
		}
		if (!horarioLaboral && usuarios < 5 && nivel > 1) {
			nivel--;
		}
		if (detenido && nivel < 2) {
			nivel = 2;
		}
		System.out.println("Nivel numérico: " + nivel);
		if (nivel == 1) {
			System.out.println("BAJA");
		} else if (nivel == 2) {
			System.out.println("MEDIA");
		} else if (nivel == 3) {
			System.out.println("ALTA");
		} else {
			System.out.println("CRÍTICA");
		}
	}

	public void ejemplo6() {
		int edad = 24;
		double sueldo = 2800;
		double importePrestamo = 25000;
		double nuevaCuota = 450;
		double deudasActuales = 300;
		boolean contratoIndefinido = true;
		double porcentajeEndeudamiento = (nuevaCuota + deudasActuales) / sueldo * 100;
		System.out.println("Endeudamiento: " + porcentajeEndeudamiento + "%");
		if (edad < 21 || edad > 65) {
			System.out.println("PRÉSTAMO DENEGADO");
		} else if (edad < 25 && importePrestamo > 20000) {
			System.out.println("PRÉSTAMO DENEGADO: máximo 20.000 €");
		} else if (importePrestamo > 50000 && !contratoIndefinido) {
			System.out.println("PRÉSTAMO DENEGADO");
		} else if (!contratoIndefinido && sueldo <= 2500) {
			System.out.println("PRÉSTAMO DENEGADO");
		} else if (porcentajeEndeudamiento > 40) {
			System.out.println("PRÉSTAMO DENEGADO");
		} else {
			System.out.println("PRÉSTAMO CONCEDIDO");
		}
	}

	public void ejemplo7() {
		int edad = 23;
		int aniosCarnet = 3;
		int accidentes = 1;
		int potencia = 220;
		boolean garaje = true;
		int riesgo = 1;
		if (edad < 18) {
			System.out.println("NO ASEGURABLE");
		} else if (accidentes > 3) {
			System.out.println("NO ASEGURABLE");
		} else {
			if (aniosCarnet < 2) {
				riesgo = 3;
			}
			if (accidentes > 2) {
				riesgo = 4;
			}
			if (potencia > 200 && edad < 25) {
				riesgo = 4;
			}
			if (aniosCarnet > 10 && accidentes == 0) {
				riesgo = 1;
			}
			if (garaje && riesgo > 1) {
				riesgo--;
			}
			if (riesgo == 1) {
				System.out.println("RIESGO BAJO");
			} else if (riesgo == 2) {
				System.out.println("RIESGO MEDIO");
			} else if (riesgo == 3) {
				System.out.println("RIESGO ALTO");
			} else {
				System.out.println("RIESGO MUY ALTO");
			}
		}
	}

	public void ejemplo8() {
		double precio = 850;		boolean premium = true;		int pedidosAnteriores = 12;		boolean tarjeta = true;
		boolean urgente = true;		boolean codigoDescuento = true;		boolean finSemana = true;
		boolean stock = true;		double descuento = 0;		double suplemento = 0;
		if (!stock) {
			System.out.println("PEDIDO CANCELADO");
		} else {
			if (premium) {
				descuento = descuento + 5;
			}
			if (pedidosAnteriores >= 10) {
				descuento = descuento + 3;
			}
			if (codigoDescuento) {
				descuento = descuento + 7;
			}
			if (precio > 500) {
				descuento = descuento + 2;
			}
			if (descuento > 15) {
				descuento = 15;
			}
			if (urgente) {
				suplemento = suplemento + 20;
			}
			if (finSemana && urgente) {
				suplemento = suplemento + 10;
			}
			if (!tarjeta && precio > 500) {
				suplemento = suplemento + 15;
			}
			double cantidadDescuento = precio * descuento / 100;
			double precioFinal = precio - cantidadDescuento + suplemento;
			System.out.println("Precio inicial: " + precio);
			System.out.println("Descuento: " + descuento + "%");
			System.out.println("Suplementos: " + suplemento);
			System.out.println("Precio final: " + precioFinal);
		}
	}
	
	

	public static void main(String[] args) {
		new Condicionales2();

	}

}
