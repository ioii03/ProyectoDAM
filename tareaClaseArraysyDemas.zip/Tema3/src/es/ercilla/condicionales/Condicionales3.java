package es.ercilla.condicionales;

public class Condicionales3 {
	public void ejemplo1() {
		int plazas = 5;
		int cochesDentro = 2;
		int opcion = 1;
		System.out.println("Coches iniciales: " + cochesDentro);
		System.out.println("Plazas libres: " + (plazas - cochesDentro));
		switch (opcion) {
		case 1:
			if (cochesDentro < plazas) {
				System.out.println("Entra un coche normal");
				System.out.println("Antes del postincremento: " + cochesDentro);
				System.out.println("Valor mostrado con cochesDentro++: " + cochesDentro++);
				System.out.println("Valor después: " + cochesDentro);
			} else {
				System.out.println("Parking completo");
			}
			break;
		case 2:
			if (cochesDentro > 0) {
				System.out.println("Sale un coche");
				System.out.println("Valor con --cochesDentro: " + --cochesDentro);
			} else {
				System.out.println("No hay coches");
			}
			break;
		case 3:
			if (cochesDentro < plazas) {
				System.out.println("Entra un coche prioritario");
				System.out.println("Valor con ++cochesDentro: " + ++cochesDentro);
			} else {
				System.out.println("Parking completo");
			}
			break;
		case 4:
			if (cochesDentro > 0) {
				System.out.println("Coches antes de salir: " + cochesDentro--);
				System.out.println("Coches después de salir: " + cochesDentro);
			} else {
				System.out.println("Parking vacío");
			}
			break;
		default:
			System.out.println("Opción no válida");
		}

		System.out.println();
		System.out.println("Estado final");
		System.out.println("Coches dentro: " + cochesDentro);
		System.out.println("Plazas libres: " + (plazas - cochesDentro));
		if (cochesDentro == 0) {
			System.out.println("Parking vacío");
		} else if (cochesDentro == plazas) {
			System.out.println("Parking completo");
		} else {
			System.out.println("Parking parcialmente ocupado");
		}
	}

	public void ejemplo2() {
		int a = 7;
		int b = 4;
		int resultado = 2;
		int opcion = 3;
		if (a > b) {
			resultado += 3;
			if (resultado >= 5) {
				resultado++;
				if (b % 2 == 0) {
					resultado *= 2;
				} else {
					resultado--;
				}
			} else {
				resultado -= 2;
			}
		} else {
			resultado = 0;
		}
		switch (opcion) {
		case 1:
			resultado += 5;
			break;
		case 2:
			resultado--;
			break;
		case 3:
			if (resultado > 10) {
				resultado -= 4;
			} else {
				resultado += 4;
			}
			break;
		case 4:
			resultado *= 2;
			break;
		default:
			resultado = -1;
		}
		if (resultado >= 10 && resultado < 15) {
			resultado++;
		} else if (resultado >= 15) {
			resultado -= 3;
		} else {
			resultado += 2;
		}
		System.out.println("Resultado final: " + resultado);
	}

	public static void main(String[] args) {
		Condicionales3 condicionales3 = new Condicionales3();
		condicionales3.ejemplo2();

	}
}
