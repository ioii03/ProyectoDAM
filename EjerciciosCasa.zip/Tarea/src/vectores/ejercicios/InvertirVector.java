package vectores.ejercicios;

import java.util.Arrays; // Importación necesaria para usar Arrays.toString

public class InvertirVector {
    public static void main(String[] args) {
        // Vector original
        int[] vector = {10, 20, 30, 40, 50};
        // --- VERSIÓN 2 (Ampliación): Invertir el propio vector (In-place) ---
        System.out.println("--- Versión 2 (Ampliación): Invertir contenido sin array auxiliar ---");
        System.out.println("Vector original: " + Arrays.toString(vector));
        int izquierda = 0;
        int derecha = vector.length - 1;

        while (izquierda < derecha) {
            int temporal = vector[izquierda];
            vector[izquierda] = vector[derecha];
            vector[derecha] = temporal;

            izquierda++;
            derecha--;
        }

        // Impresión usando Arrays.toString
        System.out.println("Vector original modificado: " + Arrays.toString(vector));
    }
}
