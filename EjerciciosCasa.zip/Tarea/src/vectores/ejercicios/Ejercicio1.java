package vectores.ejercicios;

import java.util.Arrays;

/**
 * 1. Invertir un vector Dado el siguiente vector: {10, 20, 30, 40, 50}
 * Desarrolla un programa que muestre el vector original y después sus elementos
 * en orden inverso. Como ampliación, realiza una versión que invierta el
 * contenido del propio vector, sin utilizar otro array auxiliar.
 */
public class Ejercicio1 {

	public static void main(String[] args) {
		int[] numeros = { 10, 20, 30, 40, 50 };

		System.out.println("Vector Original: " + Arrays.toString(numeros));
		for (int i = 0; i < numeros.length; i++) {

			// System.out.println(numeros[i]);
		}

		Ejercicio1.numInverso(numeros, numeros.length);
	}

	public static void numInverso(int[] numeros, int anum) {

		/*
		 * for(int i=0;i<inum.length;i++) { reverso= inum[i]/10;
		 * 
		 * 
		 * System.out.println(reverso); inum[i]=reverso;
		 * 
		 * }
		 */
		for (int j = numeros.length - 1; j >= 0; j--) {
			int reverso;
			reverso = numeros[j];
			System.out.print(" " + reverso);

		}

		System.out.println("\n" + "Vector Invertido: " + Arrays.toString(numeros));

	}

}
