package centro_educativo;

public class Alumno {

	private String nombre;
	private int nexpe;
	private double n1;
	private double n2;
	private double n3;
	private double nm;
	
	public double getNm() {
		return nm;
	}
	public void setNm(double nm) {
		this.nm = nm;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getNexpe() {
		return nexpe;
	}
	public void setNexpe(int nexpe) {
		this.nexpe = nexpe;
	}
	public double getN1() {
		return n1;
	}
	public void setN1(double n1) {
		this.n1 = n1;
	}
	public double getN2() {
		return n2;
	}
	public void setN2(double n2) {
		this.n2 = n2;
	}
	public double getN3() {
		return n3;
	}
	public void setN3(double n3) {
		this.n3 = n3;
	}
	
	public Alumno(String nombre, int nexpe, double n1, double n2, double n3) {
		this.nombre = nombre;
		this.nexpe = nexpe;
		this.n1 = n1;
		this.n2 = n2;
		this.n3 = n3;
		this.nm = (n1+n2+n3)/3;
	}
	
	public void CalculoMedia() {
		if(nm < 5) {
			System.out.println(nombre +" a suspendido con una nota de " +nm);
		}
		else if(nm >=5 && nm <=7) {
			System.out.println(nombre +" a aprobado con una nota de " +nm);
		}
		else if(nm >=8 && nm<=9) {
			System.out.println(nombre +" a sacado un notable con una nota de " +nm);
		}	
		else if(nm >9) {
			System.out.println(nombre +" a sacado un sobresaliente con una nota de " +nm);
		}
	}
	
	public static void main (String[] args) {
		Alumno a1 = new Alumno("Juan",13,2,3,4);
		Alumno a2 = new Alumno("Nico",14,5,6,7);
		Alumno a3 = new Alumno("Manu",15,8,8,8);
		Alumno a4 = new Alumno("Javier",16,9,8.75,10);
	
	a1.CalculoMedia();
	a2.CalculoMedia();
	a3.CalculoMedia();
	a4.CalculoMedia();
	
	}
}



/*
5. Se desea representar a los alumnos de un centro educativo. Cada alumno se
caracteriza por nombre, número de expediente y tres calificaciones.
Se pide crear la abstracción correspondiente y un método que calcule la
nota media.
Además:
Si la media es inferior a 5, deberá indicarse que el alumno está suspenso.
Si está entre 5 y 7, estará aprobado.
Si está entre 7 y 9, tendrá notable.
Si es igual o superior a 9, tendrá sobresaliente.
Genera 3 alumnos y muestra sus resultados.
*/