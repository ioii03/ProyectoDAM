package Ejercicios_Sistemas_de_Control;

public class Num {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[]numeros= {12,-3,8,0,15,7,-7,19,3};
		for(int i=0;i<numeros.length;i++) {
			if(numeros[i]<0) {continue;}
			else if(numeros[i]==0) {
				System.out.println("Valor Encontrado: "+numeros[i]);
			}else if(numeros[i]>18) {
				break;
			}else{
				if(numeros[i]%2==0) {
				System.out.println("Pares: "+numeros[i]);}
				else {System.out.println("Imares: "+numeros[i]);}
		}

	}

}
}