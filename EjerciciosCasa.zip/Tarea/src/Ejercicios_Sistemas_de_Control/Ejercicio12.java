package Ejercicios_Sistemas_de_Control;

public class Ejercicio12 {

	public static void main(String[] args) {
		int[] opciones = {1,2,3,4,0};	
		boolean stop=true;
		int i=0;
		while(i<opciones.length && stop) {
			i++;
			int opcion=opciones[i];
			switch(opciones[i]) {
			
			case 1:
				System.out.println("Ver libros, "+"Operacion realizada "+" Opcion: "+opcion);
			break;
			
			case 2:
				System.out.println("Prestar libros, "+"Operacion realizada "+" Opcion: "+opcion);
			break;
			
			case 3:
				System.out.println("Devolver libros, "+"Operacion realizada "+" Opcion: "+opcion);
			break;
			
			case 4:
				System.out.println("Mostrar prestamos, "+"Operacion realizada "+" Opcion: "+opcion);
			break;
			
			default:
				System.out.println("Opcion Incorrecta");
				stop=false;
			break;	
			}

			
		}

	}

}
/*
12. Menu de biblioteca
Una biblioteca dispone del siguiente menu:
1. Ver libros
2. Prestar libro
3. Devolver libro
4. Mostrar prestamos
0. Salir
Las opciones simuladas son:
int opcion1 = 1;
int opcion2 = 2;
int opcion3 = 3;
int opcion4 = 4;
int opcion5 = 0;
Se pide:- Procesar las opciones utilizando un while.
- Utilizar switch.- Para cada opcion mostrar un mensaje indicando la operacion realizada.
- Cuando la opcion sea 0, finalizar el programa.
- Si se introduce una opcion que no existe, mostrar "Opcion incorrecta".
*/