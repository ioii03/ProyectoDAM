package Ejercicios_Sistemas_de_Control;

public class Maquina {

	public static void main(String[] args) {
		int[] opcion= {2,4,1,0};
		int i=0;
		double total=0;
		int salir=1;
		while(salir==1) {
			i++;
			System.out.println("\n"+"-------MENU-------");
			System.out.println("1 Agua: 1.00€");
			System.out.println("2 Cafe: 1.50€");
			System.out.println("3 Refresco: 2.00€");
			System.out.println("4 Bocadillo: 3.50€");
			System.out.println("0 Salir");
			System.out.println("------------------"+"\n");
			switch(opcion[i-1]) {

			case 1:
				double agua = 1;
				total+=agua;
				System.out.println("Agua."+"\n"+"Importe actual: "+total+"€");
			break;
			case 2:
				double cafe = 1.5;
				total+=cafe;
				System.out.println("Cafe."+"\n"+"Importe actual: "+total+"€");
			break;
			case 3:
				double refresco = 2;
				total+=refresco;
				System.out.println("Refresco."+"\n"+"Importe actual: "+total+"€");
			break;
			case 4:
				double bocadillo = 3.5;
				total+=bocadillo;
				System.out.println("Bocadillo."+"\n"+"Importe actual: "+total+"€");
			break;
			default:
				System.out.println("SALIR"+"\n");
				salir=0;
			break;
			
			}
			
		}
		System.out.println("Importe Total: "+total+"€");
	}

}
