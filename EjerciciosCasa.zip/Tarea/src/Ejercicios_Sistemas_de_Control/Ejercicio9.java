package Ejercicios_Sistemas_de_Control;

public class Ejercicio9 {

	public static void main(String[] args) {
		int[] intentos= {20,45,33,21,37};
		int secreto=37;
		int i=0;

		do {
			
			int intento=intentos[i];
			if(i>=5) {
				System.out.println("NUMERO DE INTENTOS SUPERADO");
				break;
			}else if(intento>secreto) {
				System.out.println("El número secreto es mayor");
			}else if(intento<secreto) {
				System.out.println("El número secreto es menor");
			}else {
				System.out.println("ACERTADO");
				break;
			}
			
			
			i++;
		}while(intentos[i-1]!=secreto);
		
	}
}
/**
 9. Juego de adivinación
El número secreto es:
int secreto = 37;
Intentos:
int intento1 = 20;
int intento2 = 45;
int intento3 = 33;
int intento4 = 37;
Usar un do-while.
En cada intento:
• Si es menor → "El número secreto es mayor".
• Si es mayor → "El número secreto es menor".
• Si acierta → "ACERTADO" y terminar usando break.
Máximo 5 intentos.

 */