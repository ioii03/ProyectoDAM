package Ejercicios_Sistemas_de_Control;

public class Ejercicio10 {

	public static double calcularDescuento(double compra) {
		 double porcentaje = 0.0;

	        // Regla 2: Clasificar según el importe con condicionales
	        if (compra < 100) {
	            // Básico: 0%
	            porcentaje = 0.0;
	        } else if (compra >= 100 && compra <= 499) {
	            // Estándar: 5%
	            porcentaje = 0.05;
	        } else if (compra >= 500 && compra <= 999) {
	            // Premium: 10%
	            porcentaje = 0.10;
	        } else if (compra >= 1000) {
	            // VIP: 15%
	            porcentaje = 0.15;
	        }
		
		return compra*porcentaje;
	}
	
	
	
	
	public static void main(String[] args) {
		
		double[] compras = {120, 250, -20, 500, 75, 900, 1500, 80};
		double dinero=0;
		
		for(int i=0;i<compras.length;i++) {
		
			double compra=compras[i];
			if(compra<0) {
				System.out.println("COMPRA NEGATIVA, PRECIO ES INCORRECTO ");
				System.out.println("");
				continue;
			}
			System.out.println("Precio con Descuento: "+(compra-calcularDescuento(compra))+"€"+"\n"+"Precio Original: "+compra+"€");
			dinero+=(compra-calcularDescuento(compra));
			System.out.println("Dinero Gastado Total: "+dinero +"€");
			System.out.println(" ");
			
			if(dinero>=2000) {
				System.out.println("PROCESO DE COMPRA FINALIZADO, SUPERADO LIMITE 2000€");
				//dinero-=(compra-calcularDescuento(compra));
				//System.out.println("TE DEVOLVEMOS LO GASTADO, GASTO TOTAL: "+dinero+"€");
				System.out.println("");
				break;
			}
		}
		
		
		
		/*else if (compra<100) {
			System.out.println("Cliente basico: "+calcularDescuento(compra));
				//dinero+=compra;
			
			}else if(compra>=100 && compra<500) {
				System.out.println("Cliente estandar: "+calcularDescuento(compra));
				//dinero+=compra*0.95;
				
			}else if(compra>=500 && compra<1000) {
				System.out.println("Cliente premium: "+calcularDescuento(compra));
				//dinero+=compra*0.9;
				
			}else if(compra>1000){
				System.out.println("Cliente VIP: "+calcularDescuento(compra));
				//dinero+=compra*0.85;	
			}	*/
		
		
		
		
		
		
	}
}
/*
10. Las compras
Datos:
int[] compras = {120, 250, -20, 500, 75, 900, 1500, 80};
El programa debe recorrer las compras.
Reglas:
1. Una compra negativa es incorrecta:
continue;
2. Según el importe, usar switch o condicionales:
• Menos de 100 → cliente básico.
• 100-499 → cliente estándar.
• 500-999 → cliente premium.
• 1000 o más → cliente VIP.
3. Aplicar descuento:
• Básico: 0%.
• Estándar: 5%.
• Premium: 10%.
• VIP: 15%.
4. Acumular el dinero realmente cobrado.
5. Si el total cobrado supera los 2.000 €, finalizar el proceso con break.
6. Crear un método:
public static double calcularDescuento(double compra)
*/