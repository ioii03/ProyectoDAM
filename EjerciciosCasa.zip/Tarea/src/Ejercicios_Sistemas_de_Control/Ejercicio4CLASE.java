package Ejercicios_Sistemas_de_Control;

public class Ejercicio4CLASE {
public static void main (String[] args) {
	
	int[] numeros = {12,-3,8,0,15,-7,20,5};

	for (int i=0;i<numeros.length;i++) {
		if (numeros[i]<=-1) {
			continue;
		}else if(numeros[i]==0) {
			System.out.println("Valor cero encontrado: "+numeros[i]);
		}else if(numeros[i]>=18) {
			break;
		}else if(numeros[i]%2==0) {		
				System.out.println("Numero par: " +numeros[i]);
		}else if(numeros[i]%2!=0) {		
				System.out.println("Numero impar: " +numeros[i]);	
		}else{System.out.println("Numero: "+numeros[i]);}
	}
	//EJERCICIOAULA
	System.out.println(" ");
	double saldo=5000;
	for (int mes=1;mes<=6;mes++) {
		saldo *= 1.015;
		if(mes %3==0) 
			saldo-=120;
		System.out.println(mes +": "+saldo);
	}
System.out.println(" ");
	//EJERCICIOAULA24
	int secreto=47;
	int[] intentos= {20,70,40,49,47};
	int j=0;
do {
	int intento= intentos[j];
	if(intento<secreto)
		System.out.println("MAYOR");
	else if(intento>secreto)
		System.out.println("MENOR");
	else
		System.out.println("ACERTADO");
	j++;
}while(intentos[j-1] !=secreto);
System.out.println(" ");
	//EJERCICIOAULA11
	int numero = 987654;
	int inverso = 0;
	while (numero >0) {
		int digito = numero% 10; 
		inverso = inverso*10+ digito;
		numero /=10;
	}System.out.println(inverso);
System.out.println(" ");
	//EJERCICIOAULA17

	double deuda = 12000;
	double pago = 500;
	int meses = 0;
	while (deuda >0) {
		deuda -= pago;
		pago *=1.05;
		meses++;
	}
	System.out.println(meses);
	System.out.println(deuda);
System.out.println(" ");
	//EJERCICOAULA1b

	int consumo = 620;
	boolean placas=true;
	boolean electrico = true;
	int nocturno = 65;
	
	String tarifa="";

	if(placas && electrico) {
		if(consumo<700) {
			tarifa ="C";
		}else {
			tarifa ="B";
		}
	}else if( electrico&& nocturno >50) {
		tarifa ="C";
	}else if(placas && consumo<400) {
		
	}System.out.println(tarifa);
	
	System.out.println(" ");
//EJERCICIO AULA5a
	//EJERCICIO DE CALCULAR NOTAS
	System.out.println(" ");
	
//EJERCICIOAULA 33
	

	


}
}
