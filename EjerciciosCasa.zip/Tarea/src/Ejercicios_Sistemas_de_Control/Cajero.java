package Ejercicios_Sistemas_de_Control;

public class Cajero {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double saldo =1200;
		int i=0;
		int j=0;
		int[] opciones= {1,2,2,3};
		int[] retirado= {500,900};
	do {
		/*System.out.println("Menu");
		System.out.println("1. Consultar saldo");
		System.out.println("2. Retirar dinero");
		System.out.println("3. Salir");*/
		i++;
		switch(opciones[i-1]) {
		case 1:
			System.out.println("saldo: "+saldo);
		break;
		case 2:
			if(retirado[j] <=saldo) {
				saldo-=retirado[j];
			System.out.println("Dinero retirado "+saldo);
			}else {System.out.println("ERROR, saldo insuficiente "+saldo+"€ ,cantidad que se queria retirar: "+retirado[j]);}
			j++;
		break;
		case 3:
			System.out.println("Has pulsado Salir, vuelva pronto");
		break;
		default:
			System.out.println("\n"+"ERROR"+"\n");
		break;
		}
		
	}while(opciones[i]!=3);
	
	
	}

}
