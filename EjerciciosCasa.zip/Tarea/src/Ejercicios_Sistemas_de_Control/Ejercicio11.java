package Ejercicios_Sistemas_de_Control;

public class Ejercicio11 {

	public static void main(String[] args){
		int[] temperaturas = {18, 22, -5, 31, 25, 40, 19, 45, 23};
		
		for(int i=0;i<temperaturas.length;i++) {
			int temp = temperaturas[i];
			if(temp<0) {
				System.out.println("Temperatura Negativa: "+temp +"ºC");
				continue;
			}
			else if(temp>0 && temp<=20) {
				System.out.println("Temperatura Baja: "+temp +"ºC");
			}
			else if(temp>20 && temp<30) {
				System.out.println("Temperatura Normal: "+temp +"ºC");
			}
			else if(temp>30 && temp<=40) {
				System.out.println("Temperatura Alta: "+temp +"ºC");
			}
			
			
			
			else if (temp>40) {
				System.out.println("Temperatura Extrema: "+temp +"ºC");
				break;
			}		
		}
		
		
	
	
	
	}
}
/*
11. Control de temperaturas
Se dispone de las siguientes temperaturas:
int[] temperaturas = {18, 22, -5, 31, 25, 40, 19, 45};
Se pide:- Recorrer el array con un for.- Si la temperatura es menor que 0, mostrar "Temperatura negativa" y utilizar continue.
- Si la temperatura supera los 40 grados, mostrar "Temperatura extrema" y terminar el recorrido con
break.- Para el resto de temperaturas: menor de 20 -> "Temperatura baja"; de 20 a 29 -> "Temperatura
normal"; de 30 a 40 -> "Temperatura alta".- Mostrar cada temperatura junto con su clasificacion
*/