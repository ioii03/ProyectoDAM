package Ejercicios_Sistemas_de_Control;

//EJERCICOAULA62
public class EjercicioLargoCLASE {

	public static int categoria(double compra) {
		if(compra < 100) {
			return 1;
		}
		if(compra < 500) {
			return 2;
		}
		if(compra < 1000) {
			return 3;
		}return 4;			
	}
	
	public static double descuento(int categoria) {
		 switch (categoria) {
		 case 1:
			 return 0;
		 case 2:
			 return 5;
		 case 3:
			 return 10;
		 case 4:
			 return 15;
		default:
			 return 0;	 
		 }
	}
	
	
	
	public static void main(String[] args) {
		double[] compras = {80,250,-30,520,1100,75,1600,400};
		double facturacion =0;
		int basic=0;
		int standar=0;
		int premium=0;
		int vip=0;
		for(double compra : compras) { //for_each IMPORTANTE --> hace que el for siga hasta que no haya nada en compras
			if(compra<0) {
				System.out.println("compra incorrecta");
				System.out.println("");
				continue;
			}
		int categoria = categoria(compra);
		double porcentaje=descuento(categoria);
		switch (categoria) {
		case 1:
			basic++;
			break;
		case 2:
			standar++;
			break;
		case 3:
			premium++;
			break;
		case 4:
			vip++;
			break;			
			}
		
		double precioFinal = compra - compra * porcentaje / 100;
		facturacion += precioFinal;
		System.out.println("Compra: " + compra);
		System.out.println("Categoria: "+ categoria);
		System.out.println("Descuento: "+porcentaje);
		System.out.println("Precio Final: "+precioFinal);
		System.out.println("Acumulado: "+facturacion);
		System.out.println("");
	
		if(facturacion > 3500) {
			System.out.println("LIMITE ALCANZADO");
		
			break;
			}
		
		}
		System.out.println("Facturado: "+facturacion);
		System.out.println("Basicos: "+basic);
		System.out.println("Estandar: "+standar);
		System.out.println("Premium: "+premium);
		System.out.println("VIP: "+vip);
		System.out.println("");
	
		
		
		
		
		
		
	}

}
