package Ejercicios_Sistemas_de_Control;

public class Ejercicio5 {

	public static void main(String[] args) {

		double saldo = 1200;
// 1 Consultar saldo
// 2 Retirar
// 2 Retirar
// 3 Salir

	int operacion[] = {1,2,2,3};
	double retirada[] = {500,900};
		
	 	int i=0;
		int j=0;
		int opcion;
		
		
		do {
			//menu
			System.out.println("Menu");
			System.out.println("1. Consultar saldo");
			System.out.println("2. Retirar dinero");
			System.out.println("3. Salir");
			
			opcion = operacion[i];
			i++;
			
			switch(opcion) {
			
			case 1:
				System.out.println("Saldo en la cuenta: "+saldo+"€"+"\n");
			break;
			
			case 2:
				double cantRet = retirada[j];
				j++;
				if (cantRet <= saldo) {
				saldo -= cantRet;
				System.out.println("Dinero Retirado: "+(saldo)+"€"+"\n");
				}else {System.out.println("Error, no hay suficiente Saldo"+"\n");}
			break;
			
			case 3:
				System.out.println("Has pulsado Salir, vuelva pronto");
			break;
				
			default:
				System.out.println("\n"+"ERROR"+"\n");
			break;
			}
		
	}while(opcion !=3);
	
	
	
	
	}

}


/*
5. Cajero automático
Datos iniciales:
double saldo = 1200;
Operaciones:
int operacion1 = 1; // Consultar saldo
int operacion2 = 2; // Retirar
int operacion3 = 2; // Retirar
int operacion4 = 3; // Salir
double retirada1 = 500;
double retirada2 = 900;
Menú:
1. Consultar saldo
2. Retirar dinero
3. Salir
Se pide:
• Usar do-while.
• Procesar las operaciones mediante switch.
• No permitir retirar más dinero del disponible.
• Si se intenta retirar 900 € tras haber retirado 500 €, mostrar "Saldo
insuficiente".
• Finalizar al seleccionar opción 3.
 */

