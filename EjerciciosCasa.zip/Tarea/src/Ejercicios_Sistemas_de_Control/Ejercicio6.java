package Ejercicios_Sistemas_de_Control;

public class Ejercicio6 {

	

	
	public static boolean buscarNumero(int[] valores, int buscado) {
		
		for(int i=0 ; i<valores.length ; i++) {
		if(valores[i]==buscado){
			//System.out.println("GANASTE "+valores[i]);
			return true;
		}
		//System.out.println("hola mundo "+valores[i]); 	
	}
		return false;
		
	}	
	
	
	public static void main(String[] args) {
		int buscado = 22;
		int valores[] = {4, 9, 13, 23, 31, 45, 50, 22};
		
		if (buscarNumero(valores, buscado)) {
            System.out.println("Número encontrado");
        } else {
            System.out.println("Número no encontrado");
        }
	}

}



/*
6. Búsqueda de un número
Se dispone de:
int[] valores = {4, 9, 13, 22, 31, 45, 50};
int buscado = 22;
Crear un método:
public static boolean buscarNumero(int[] valores, int buscado)
El método debe:
• Recorrer el array con un for.
• Si encuentra el valor, utilizar return true.
• Si termina el recorrido sin encontrarlo, devolver false.
Desde main, mostrar:
Número encontrado ó Número no encontrado
*/