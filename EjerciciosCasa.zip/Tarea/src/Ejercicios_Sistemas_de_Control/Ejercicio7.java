package Ejercicios_Sistemas_de_Control;

public class Ejercicio7 {

	
	
	public static void main(String[] args) {
//Notas:
		int apro=0;
		int susp=0;
		int sobr=0;
		double[] notas = {7.5, 4, 9, -1, 6, 11, 5, 3};		
			System.out.println("========TABLA DE NOTAS========");
		for(int i=0;i<notas.length;i++) {
						
			if(notas[i]<0 || notas[i]>10) {
				System.out.println("ERROR, nota no valida: "+notas[i]);
				continue;
			}else if(notas[i]<5) {
				System.out.println("Suspenso "+notas[i]);
				susp++;
				
			}else if(notas[i]>=5  && notas[i]<=8) {
				System.out.println("Aprobado: "+notas[i]);		
				apro++;
				
			}else if(notas[i]>=9 && notas[i]<=10) {
				System.out.println("Sobresaliente: "+notas[i]);
				sobr++;
				
			}
		
			
			}
			System.out.println("==============================");
			System.out.println("");
			System.out.println("=========RESUMEN NOTAS========");
			System.out.println("Aprobados: "+apro);
			System.out.println("Suspensos: "+susp);
			System.out.println("Sobresaliente: "+sobr);
			System.out.println("==============================");
			
			
		}
	
	
	}






/*
 7. Contador de aprobados con continue
Notas:
double[] notas = {7.5, 4, 9, -1, 6, 11, 5, 3};
Reglas:
• Las notas menores que 0 o mayores que 10 son inválidas.
• Para las inválidas, mostrar un mensaje y utilizar continue.
• Contar:
o aprobados,
o suspensos,
o sobresalientes.
Considerar sobresaliente si la nota es >= 9.
Mostrar al final:
Aprobados: X
Suspensos: X
Sobresalientes: X
 */
