package Ejercicios_Sistemas_de_Control;

public class Ejercicio8 {

	public static void main(String[] args) {
		int capacidad = 5;
		int ocupados = 0;
	
		String [] vehiculo = {"Coche","Moto","Tren","Coche","Camion","coche","Moto"};
		int i=0;
		do{
			i++;
			
		switch(vehiculo[i]) {
		
		case "Coche":
			ocupados+=1;
		break;
		
		case "Moto":
			ocupados+=1;
		break;
		
		case "Camion":
			ocupados+=2;
		break;
		default:
		System.out.println("Error, vehiculo no disponible: "+vehiculo[i]+"\n");
		continue;
		
		}
		
			
		if(ocupados>capacidad){
			System.out.println("Vehiculo rechazado: "+vehiculo[i]+"\n");
			
		}else if(ocupados==capacidad) {
			System.out.println("Vehiculo: "+vehiculo[i]+ "\n"+"Plazas ocupadas: "+ ocupados+" plazas"+"\n");
			System.out.println("Capacidad maxima alcanzada: "+ocupados+" plazas");
			break;
		
		}else{System.out.println("Vehiculo: "+vehiculo[i]+ "\n"+"Plazas ocupadas: "+ ocupados+" plazas"+"\n");}
			
			
		}while(i<=capacidad);
	}
	
	
	
}

/*8. Aparcamiento
Un parking tiene capacidad para:
int capacidad = 5;
int ocupados = 0;
Llegan estos vehículos:
String vehiculo1 = "coche";
String vehiculo2 = "moto";
String vehiculo3 = "coche";
String vehiculo4 = "camion";
String vehiculo5 = "moto";
String vehiculo6 = "coche";
Reglas:
• coche ocupa 1 plaza.
• moto ocupa 1 plaza.
• camion ocupa 2 plazas.
Se pide:
• Utilizar switch.
• Simular entradas con un while.
• Si no hay espacio suficiente, mostrar "Vehículo rechazado".
• Si el parking llega exactamente a su capacidad, salir con break.
*/