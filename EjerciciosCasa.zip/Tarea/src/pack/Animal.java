package pack;

public class Animal {

	private String nombre;
	private int p1;
	private int p2;
	private int p3;
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getP1() {
		return p1;
	}
	public void setP1(int p1) {
		this.p1 = p1;
	}
	public int getP2() {
		return p2;
	}
	public void setP2(int p2) {
		this.p2 = p2;
	}
	public int getP3() {
		return p3;
	}
	public void setP3(int p3) {
		this.p3 = p3;
	}

	public Animal (String nombre, int p1, int p2, int p3) {
		this.nombre = nombre;
		this.p1 = p1;
		this.p2 = p2;
		this.p3 = p3;
		
	}
	
	public static void main(String [] args) {
		
	}
	
	
	

	
	
	
	
}



/*

Animal
String nombre buho
int peso1 1
int peso2 1
int peso3 2

Si Media supera 3 el buho esta gordo
*/