package pack;

public class Supermercado {
	private String nombre;
	private int id;
	private String seccion;
	private double precio;
	private int posicion;
	private int nestante;
	
//		GETTER/SETTER

	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSeccion() {
		return seccion;
	}
	public void setSeccion(String seccion) {
		this.seccion = seccion;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	public int getPosicion() {
		return posicion;
	}
	public void setPosicion(int posicion) {
		this.posicion = posicion;
	}
	public int getNestante() {
		return nestante;
	}
	public void setNestante(int nestante) {
		this.nestante = nestante;
	}
	public Supermercado(String nombre, int id, String seccion, double precio, int posicion, int nestante) {
		this.nombre = nombre;
		this.id = id;
		this.seccion = seccion;
		this.precio = precio;
		this.posicion = posicion;
		this.nestante = nestante;
		
	}

	public void array() {
		//									NOMBRE   ID SECCION PRECIO   POSICION Nestante
		Supermercado sec1 = new Supermercado("Yogur",30,"Lacteos",1.15,		1,		1);
		Supermercado sec2 = new Supermercado("Platano",20,"Frutas",1.95,	2,		2);
		Supermercado sec3 = new Supermercado("Tomate",10,"Verduras",2.75,	3,		3);
		Supermercado sec4 = new Supermercado("lechuga",10,"Verduras",0.99,	4,		3);
		Supermercado sec5 = new Supermercado("Mesa",  40,"Muebles",69.99,	5,		4);
		Supermercado [] seccion = {sec1,sec2,sec3,sec4,sec5};
		
		
		
		
		for (int i = 0; i < seccion.length; i++ ) {
	        System.out.println("- Sección: " +seccion[i].getSeccion());	        
	        System.out.println("Nombre del producto: " +seccion[i].getNombre());
			System.out.println("Numero de estante: " +seccion[i].getNestante());
			System.out.println("Numero de posicion: " +seccion[i].getPosicion());	        
	        System.out.println("Id del producto: " +seccion[i].getId());
			System.out.println("Precio: " +seccion[i].getPrecio() +"€");
			System.out.println("");
	        		
	    
		}
	}
	
	public static void main(String[] args) {
		
		
	
		
		
		Supermercado supermercado = new Supermercado(null, 0, null, 0, 0, 0);
		supermercado.array();
		
		
	
		/*
		 
	 
			 	
		  if(producto.getSeccion() == 1) {
			System.out.println("Sección: " +producto.getSeccion());
		}
		
		*/
		
		
	}
	




}
/*2. Partiendo de la clase anterior, suponemos que la sección es, a su vez, un
objeto diferente caracterizado por el número de posición y número de
estante. Realiza la abstracción necesaria de la sección y las modificaciones
necesarias en producto para que tenga en cuenta este nuevo tipo de objeto.

*/