package pack;

public class Mamiferos {
	private String nombre;
	private String especie;
	private String pais;
	private double peso;
	private int edad;
	private int numero;

	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getEspecie() {
		return especie;
	}
	public void setEspecie(String especie) {
		this.especie = especie;
	}
	public String getPais() {
		return pais;
	}
	public void setPais(String pais) {
		this.pais = pais;
	}
	public double getPeso() {
		return peso;
	}
	public void setPeso(double peso) {
		this.peso = peso;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}


	public Mamiferos (String nombre, String especie, String pais, double peso, int edad, int numero) {
	this.nombre = nombre;
	this.especie = especie;
	this.pais = pais;
	this.peso = peso;
	this.edad = edad;
	this.numero = numero;
	}

	
	public static void main(String[] args) {
	Mamiferos animal = new Mamiferos ("nombre", "pais", "especie", 19.6, 8, 9);
	animal.setNombre("Perro");
	animal.setPeso(19.4);
	animal.setEdad(7);
	animal.setPais("test1");
	animal.setEspecie("Canis lupus familiaris");
	animal.setNumero(100000);
	System.out.println("Nombre: " +animal.getNombre());
	System.out.println("Peso: " +animal.getPeso() +" kg");	
	System.out.println("Edad: " +animal.getEdad() +" años");
	System.out.println("Especie: " +animal.getEspecie());
	System.out.println("Pais de Origen: " +animal.getPais());
	System.out.print("Numero de habitantes: " +animal.getNumero());
	
	

	
		Mamiferos animal1 = new Mamiferos("Rex", "Perro", "España", 19.4, 7,2);
	    Mamiferos animal2 = new Mamiferos("Michi", "Gato", "Francia", 4.2, 3,2);
	    Mamiferos animal3 = new Mamiferos("Dumbo", "Elefante", "India", 5000.0, 20,2);

    Mamiferos [] animales = {animal1, animal2, animal3};

    for (int i = 0; i < animales.length; i++) {
        System.out.println(animales[i].getNombre() + " - " + animales[i].getEspecie());
    }

    // O acceder a uno concreto:
    System.out.println(animales[2].getEspecie()); // Gato





	}

}















	/*Mamiferos[]animal = {animal1, animal2, animal3};{

	animal[1].getEspecie();
	animal[2].getEspecie();
	}
*/







	/**quiero represnetar un animal
	caraterizado por nombre especie peso y edad

	Especie contiene pais de procedencia y numeros de habitantes


	Animal
	String nombre buho
	int peso1 1
	int peso2 1
	int peso3 2

	Si Media supera 3 el buho esta gordo
*/
