package pack;

public class OperadoresCombinados {

	public void combinacion1() {
		int a = 5;
		int b = 3;

		int resultado = a++ + ++b;

		System.out.println("a = " + a);
		System.out.println("b = " + b);
		System.out.println("resultado = " + resultado);
	}

	public void combinacion2() {
		int a = 4;
		int resultado = a++ + ++a + a--;
		System.out.println("a = " + a);
		System.out.println("resultado = " + resultado);
	}

	public void combinacion3() {
		int a = 3;
		int b = 5;
		int resultado = a++ * 2 + --b;
		System.out.println("a = " + a);
		System.out.println("b = " + b);
		System.out.println("resultado = " + resultado);
	}

	public void combinacion4() {
		int x = 2;
		int resultado = x++ * ++x + x--;
		System.out.println("x = " + x);
		System.out.println("resultado = " + resultado);
	}

	public void combinacion5() {
		int a = 3;
		int resultado = (a++ + ++a) * a--;
		System.out.println("a = " + a);
		System.out.println("resultado = " + resultado);
	}

	public void combinacion6() {
		int a = 6;
		int b = 3;
		int resultado = a++ / b-- + ++a;
		System.out.println("a = " + a);
		System.out.println("b = " + b);
		System.out.println("resultado = " + resultado);
	}

	public void combinacion7() {
		int a = 5;
		int b = 6;
		if (a++ < b && ++a == b + 1) {
			System.out.println("Condición verdadera");
		} else {
			System.out.println("Condición falsa");
		}
		System.out.println("a = " + a);
		System.out.println("b = " + b);
	}

	public void combinacion8() {
		int a = 10;
		if (a++ < 5 && ++a > 10) {
			System.out.println("Verdadero");
		}
		System.out.println("a = " + a);
	}

	public void combinacion9() {
		int a = 5;
		if (a++ == 6 || ++a == 7) {
			System.out.println("Verdadero");
		}
		System.out.println("a = " + a);
	}

	public void combinacion10() {
		int a = 2;
		int b = 4;
		int resultado = a++ * ++b - --a + b--;
		System.out.println("a = " + a);
		System.out.println("b = " + b);
		System.out.println("resultado = " + resultado);
	}

	public static void main(String[] args) {
		OperadoresCombinados operadoresCombinados = new OperadoresCombinados();
		operadoresCombinados.combinacion10();
	}

}