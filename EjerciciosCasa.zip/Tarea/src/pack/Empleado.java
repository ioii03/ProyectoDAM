package pack;

public class Empleado {
	private String nombre;
	private double salario;
	private int antiguedad;
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}
	public int getAntiguedad() {
		return antiguedad;
	}
	public void setAntiguedad(int antiguedad) {
		this.antiguedad = antiguedad;
	}


	public Empleado(String nombre, double salario, int antiguedad) {
		this.nombre = nombre;
		this.salario = salario;
		this.antiguedad = antiguedad;
	}
	
	
	public void emp1(){
		
		
		if (salario >= 1000 && antiguedad >= 3 ) {
			double resultado = (double) ((salario *0.1) + salario);
			System.out.println("Suledo incrementado un 10% ");
			System.out.println("Salario: " +resultado +"€");
			System.out.println("");
			
		} else {
			System.out.println("Salario: " +salario +"€");
			System.out.println("");
		}
	
	}
	
	
	
	
	
	public static void main(String[] args) {
		Empleado emp1 = new Empleado("Uno",1000,2);
		Empleado emp2 = new Empleado("Dos",1000,3);
		Empleado emp3 = new Empleado("Tres",1500,3);
		Empleado emp4 = new Empleado("Cuatro",2000,3);
		Empleado emp5 = new Empleado("Cinco",3000,3);
		Empleado emp6 = new Empleado("Seis",4000,3);
	Empleado [] emp = {emp1,emp2,emp3,emp4,emp5,emp6};
		
	//Empleado emp = new Empleado("uno",1000,3);
	//emp.setNombre("uno");
	//System.out.println("Nombre :" +emp.getNombre());
	//
	//emp.emp1();
	
	for (int i = 0; i < emp.length; i++ ) {
		System.out.println("Nombre del Empleado: " +emp[i].getNombre());
		
		System.out.println("Salario original: " +emp[i].getSalario() +"€");
		
		if (emp[i].getSalario() >= 1000 && emp[i].getAntiguedad() >= 3) {
			
			System.out.println("Suledo incrementado un 10% ");
			System.out.println ("Salario: " +(emp[i].getSalario() *0.1 +emp[i].getSalario() )+ "€");
		
		}
		
		/*If (emp[i].getSalario() >= 1000) {
			System.out.println("Retencion de impuestos: ");
		}*/
		
		if (emp[i].getSalario() >= 1500 && emp[i].getAntiguedad() >= 3) {
			
			emp[i].setSalario ((emp[i].getSalario() *0.1 +emp[i].getSalario() ));
			System.out.println("Retencion de impuesto especial de 50€: ");
			System.out.println ("Salario: " +(emp[i].getSalario() -50 )+ "€");
		}
		
		if ((emp[i].getSalario() >= 2000 && emp[i].getSalario() <= 3000) && emp[i].getAntiguedad() >= 3) {
			
			emp[i].setSalario ((emp[i].getSalario() -50 ));
			System.out.println("Retencion del 2%:");
			System.out.println ("Salario: " +(emp[i].getSalario() *0.02 +emp[i].getSalario())+ "€");
		}
		
		
		//CREAR EMPLEADO 6 Y CONFIGURARLO
		
		
		System.out.println("");
		
	}
		
	
	
	
	}
	
	
	
	
	
	
	
}


/*
3. Tenemos que calcular la nómina de un empleado de una empresa que está basada
en una serie de premisas para hacer los ajustes necesarios:
a. Si el empleado cobra más de 1000€ y tiene más de 3 años de antigüedad
se le incrementa en un 10% el sueldo.
b. Si el sueldo incrementado supera los 1500€ se le aplica una retención
de impuestos especial de 50€.
c. Si el empleado cobra entre 2000€ y 3000€ la retención es del 2%.
Se pide crear la abstracción correspondiente de un empleado, teniendo en cuenta
que se caracteriza por /nombre, salario y antigüedad/, generar 3 diferentes y
calcular su nómina, imprimiendo el resultado por pantalla.


*/