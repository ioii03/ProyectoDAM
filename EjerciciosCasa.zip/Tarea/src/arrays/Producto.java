package arrays;

public class Producto {
	
	private int idProducto;
	private String categoria;
	private int precio;
	public int getIdProducto() {
		return idProducto;
	}
	public void setIdProducto(int idProducto) {
		this.idProducto = idProducto;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public int getPrecio() {
		return precio;
	}
	public void setPrecio(int precio) {
		this.precio = precio;
	}
	
	public Producto(int idProducto, String categoria, int precio) {
		this.idProducto=idProducto;
		this.categoria=categoria;
		this.precio=precio;
	}
	
}


/*
Producto

-idProducto int
-categoria String
-precio int


Almacen(main)

-Crear estructura para el almacen de 5 productos
-Metodo que añada 1 producto al almacen (PRODUCTO)
-metodo que modifique un producto (PRODUCTO,PRECIO)
-metodo que elimine un producto (PRODUCTO)


*/