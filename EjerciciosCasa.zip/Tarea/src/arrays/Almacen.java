package arrays;

public class Almacen { // MAIN //

	public void AddPro(int i) {
		if( pro[i].equals(pro[i])) {
			//pro[i].setCategoria("");
			//System.out.println("hola"+"\n");
		}
		
		/*else if (pro[i] == p1 && pro[i]== null){
			System.out.println("p1 CARNE");
			
		}*/
		
	}
	
	
	public void MostrarDatos() {
	
		
		
		for(int i = 0; i<pro.length;i++) {								
		System.out.println("id: "+pro[i].getIdProducto());
		System.out.println(pro[i].getCategoria());
		System.out.println(pro[i].getPrecio()+"€");
		System.out.println();

		
		}
	}
	
	
	public static void main(String[] args) {
		Almacen al = new Almacen();
		Producto p1 = new Producto(1,"carne",10);
		Producto p2 = new Producto(2,"pescado",20);
		Producto p3 = new Producto(3,"fruta",30);
		Producto p4 = new Producto(4,"verdura",40);
		Producto p5 = new Producto(4,"verdura",40);
	
		Producto[]pro = {p1,p2,p3,p4,p5};
		
		System.out.println("+-------------+"+"\n");
		
		al.MostrarDatos();
		
		System.out.println("+-------------+"+"\n");
		//al.MostrarDatos();
	
	}
}

/*
Producto

-idProducto int
-categoria String
-precio int


Almacen(main)

-Crear estructura para el almacen de 5 productos
-Metodo que añada 1 producto al almacen (PRODUCTO)
-metodo que modifique un producto (PRODUCTO,PRECIO)
-metodo que elimine un producto (PRODUCTO)


*/