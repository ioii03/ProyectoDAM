package tienda;



public class Producto{
	
	 private String nombre;
	 private double precio;


	 public String getNombre() {
	     return this.nombre;
	 }

	 public void setNombre(String nombre) {
	     this.nombre = nombre;
	 }

	 public double getPrecio() {
	     return this.precio;
	 }

	 public void setPrecio(double precio) {
	     this.precio = precio;
	 }


	 public Producto(String productoNombre, double productoPrecio){
	     
	     this.nombre = productoNombre;
	     this.precio = productoPrecio;

	 }

	     
	}