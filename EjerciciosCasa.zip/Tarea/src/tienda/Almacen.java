package tienda; 
//Producto tiene familia nombre y precio
//Almacén tiene dos metodos comprarProducto y venderProducto
//Presupuesto: 60k€
//No podemos superar el 75%
//Simula la compra de productos (al menos 5)
//Cantidad total gastada por compra
//Presupuesto restante por compra
//Cantidad total gastada
//Prespuesto final restante

public class Almacen{
 private double presupuesto;

 public double getPresupuesto() {
     return this.presupuesto;
 }
 public void setPresupuesto(double presupuesto) {
     this.presupuesto = presupuesto;
 }

 
 public Almacen(double presupuestoAlmacen){
     this.presupuesto = presupuestoAlmacen * 0.75;
 }

 private void comprarProducto(Producto producto){
     if (producto.getPrecio() < getPresupuesto()){
         presupuesto -= producto.getPrecio();
         
         System.out.println("Se ha comprado " + producto.getNombre() + " por " + producto.getPrecio() +"€");
         System.out.println("El presupuesto restante es: " + getPresupuesto() +"€");
         System.out.println("-----------------------------------------------------");
     }else{
         System.out.println("El producto " + producto.getNombre() + " es muy caro ");
         System.out.println("Al costar " +producto.getPrecio() +"€ y solo tener "+getPresupuesto()+"€ de presupuesto");
         System.out.println("-----------------------------------------------------");
     }
 }

 private void venderProducto(Producto producto){
     presupuesto += producto.getPrecio();
     System.out.println("Se ha vendido " + producto.getNombre() + " por " + producto.getPrecio() +"€");
     System.out.println("Ahora el presupuesto es de " + getPresupuesto() + "€");
     System.out.println("-----------------------------------------------------");
 }

 public static void main(String[] args) {
     Almacen almacen = new Almacen(60000);

     Producto Camisetas = new Producto(/*"Ropa",*/ "Camisetas", 2000);
     Producto Bicicletas = new Producto(/*"VMP",*/"Bicicletas", 25000);
     Producto Botellas = new Producto(/*"Bebidas",*/ "Botellas", 5000);
     Producto Canicas = new Producto(/*"Juguetes",*/ "Canicas", 20000);
     Producto Ordenadores = new Producto(/*"Electronica",*/ "Ordenadores", 10000);        
     	 
     System.out.println("-----------------------------------------------------");
     
     	 almacen.comprarProducto(Canicas);
         almacen.comprarProducto(Camisetas);
         almacen.comprarProducto(Bicicletas);
         almacen.comprarProducto(Botellas);
         almacen.comprarProducto(Ordenadores);
         almacen.venderProducto(Canicas);
         almacen.comprarProducto(Bicicletas);
     }
 
}
