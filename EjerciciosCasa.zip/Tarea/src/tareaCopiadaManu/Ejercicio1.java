package tareaCopiadaManu;

public class Ejercicio1 {

	public static void main(String[] args) {
		String[] usuarios = { "admin", "dam", "dam" };
		String[] contraseñas = { "1234", "1234", "java21" };
		String usuarioCorrecto = "dam";
		String contraseñaCorrecta = "java21";
		int num_errores = 0;
		int f = 3;
		for (int i = 0; i < usuarios.length; i++) {
			if (usuarios[i].equals(usuarioCorrecto) && contraseñas[i].equals(contraseñaCorrecta)) {
				System.out.println("Acceso concedido");
				break;
			} else {
				num_errores++;
				if (num_errores != f) {
					System.out
							.println("Has fallado fracasado " + num_errores + " veces. Te quedan " + (f - num_errores));
				} else {
					System.out.println("Cuenta bloqueada");
				}
			}
		}
	}

}

/*
 * public static void main(String[] args) {
 * 
 * String userC = "dam"; String passC = "java21";
 * 
 * String user1= "admin"; String pass1= "1234";
 * 
 * String user2= "dam"; String pass2= "1234";
 * 
 * String user3= "dam"; String pass3= "java21";
 * 
 * 
 * 
 * //Ejercicio1 u1 = new Ejercicio1(); //Ejercicio1 u2 = new Ejercicio1();
 * 
 * int error = 0; int f = 3;
 * 
 * for (int i=0; i<f; i++) { error++; if(userC==user1 && passC==pass1 &&
 * error==1) { //error ++; System.out.println("Acceso denegado " + (error)); }
 * if(userC==user2 && passC==pass2 && error==2){ //error ++;
 * System.out.println("Acceso denegado " + (error)); } if(userC==user3 &&
 * passC==pass3 && error==3) {
 * 
 * System.out.println("Acceso concedido " + (error)); }
 * 
 * 
 * }
 * 
 * }
 */
