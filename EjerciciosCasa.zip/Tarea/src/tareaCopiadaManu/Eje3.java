package tareaCopiadaManu;

public class Eje3 {

	private String nombre;
	private int opcion;
	private double producto;	
	
	public String getNombre() {
		return this.nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getOpcion() {
		return this.opcion;
	}
	public void setOpcion(int opcion) {
		this.opcion = opcion;
	}
	public double getProducto() {
		return this.producto;
	}
	public void setProducto(double producto) {
		this.producto = producto;
	}

	public Eje3(int opcion,String nombre,double precio) {
		this.nombre = nombre;
		this.opcion = opcion;
		this.producto = precio;
	}

	public static void main(String[] args) {
	
		Eje3 s1= new Eje3(0,"",0);
		Eje3 s2= new Eje3(1,"agua",1);
		Eje3 s3= new Eje3(2,"cafe",1.5);
		Eje3 s4= new Eje3(3,"refresco",2);
		Eje3 s5= new Eje3(4,"bocadillo",3.5);
		
		Eje3 [] salida = {s1,s2,s3,s4,s5};
		
		/*int opcion[] = {1,2,3,4};
		String nombre[] = {"agua","cafe","refresco","bocadillo"};
		double producto[] = {1,1.5,2,3.5};*/
		
		boolean stop=false;	
		
		//for(int i =0; i<salida.length ; i++) {
			stop=false;
		//boolean SALIR = true;
				
			int j = 4;
		while(j<salida.length && stop==false) {
			
			switch (j/*salida[j].getOpcion()*/) {
			case 1:
				System.out.println(salida[j].getNombre()+" " + salida[j].getProducto()+"€" + " opcion: " + salida[j].getOpcion());
				
				
				
				
				j++;
					//stop=true;
					
			break;	
			case 2:

				System.out.println(salida[j].getNombre()+" " + salida[j].getProducto()+"€" + " opcion: " + salida[j].getOpcion());
				
				
// GUARDAR IMPORTANTE	System.out.println(salida[i].getNombre()+" " + salida[i].getProducto()+"€" + " opcion: " + salida[i].getOpcion());
				
				//System.out.println(nombre[i]+" " + producto[i]+"€" + " opcion: " + opcion[i]);
				//stop=false;
					j++;
					//stop=true;
				break;	
			case 3:
				System.out.println(salida[j].getNombre()+" " + salida[j].getProducto()+"€" + " opcion: " + salida[j].getOpcion());
				
				//System.out.println(nombre[i]+" " + producto[i]+"€" + " opcion: " + opcion[i]);
				//stop=false;
				//opcion[i] =opcion[i] +1; i=opcion[i];
					j++;
					//stop=true;
				break;
			case 4:
				System.out.println(salida[j].getNombre()+" " + salida[j].getProducto()+"€" + " opcion: " + salida[j].getOpcion());
				
				//System.out.println(nombre[i]+" " + producto[i]+"€" + " opcion: " + opcion[i]);
				//stop=false;
				//opcion[i] =opcion[i] +1; i=opcion[i];
					j++;
				stop=true;
				break;
			default:
				System.out.println("SALIR"+"\n");
				stop=true;
				break;
				
			}
			
		}
		System.out.println("final del FOR");
		//System.out.println(salida[j].getOpcion());
	}
	//}
}
