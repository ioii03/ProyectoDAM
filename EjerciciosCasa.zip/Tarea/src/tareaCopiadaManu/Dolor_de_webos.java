package tareaCopiadaManu;

import java.util.Scanner;

public class Dolor_de_webos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		int numero = sc.nextInt();
		int b = (numero / 10) % 10;
		int a = (numero % 10);

		if (numero >= 0 && numero <= 9) {
			System.out.println();
		}

		System.out.println("\n" + "b: " + b + " a: " + a);

	}

}
