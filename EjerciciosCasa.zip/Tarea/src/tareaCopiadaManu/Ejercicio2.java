package tareaCopiadaManu;

public class Ejercicio2 {
	public static void main(String[] args) {
		int[] nota = { 3, -6, 5, 7, 12, 9, 10 };
		for (int i = 0; i < nota.length; i++) {
			int notas = nota[i];
			if (notas < 0 || notas > 10) {
				// System.out.println("\n" + "Nota incorrecta: " + notas + "\n");
				continue;
			}
			switch (notas) {
			case 0, 1, 2, 3, 4:
				System.out.println("Suspenso: " + notas);
				break;
			case 5:
				System.out.println("Suficiente: " + notas);
				break;
			case 6:
				System.out.println("Bien: " + notas);
				break;
			case 7, 8:
				System.out.println("Notable: " + notas);
				break;
			case 9, 10:
				System.out.println("Sobresaliente: " + notas);
				break;

			default:
				System.out.println("Nota incorrecta");
				break;
			}
		}
	}
}
