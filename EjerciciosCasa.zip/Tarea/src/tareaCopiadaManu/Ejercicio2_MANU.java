package tareaCopiadaManu;

import java.util.Scanner;

public class Ejercicio2_MANU {
	public static void main(String[] args)  {
		Scanner sc = new Scanner(System.in);
		System.out.println("A: ");
		int a = sc.nextInt();
		System.out.println("B: ");
		int b = sc.nextInt();
		System.out.println("C: ");
		int c = sc.nextInt();
		sc.close();
		double discriminante = (Math.pow(b, 2) -(4*a*c));
		if(discriminante >0) {
		double x1= -b + Math.sqrt(Math.pow(b,2) - (4*a*c));
		double x2= -b - Math.sqrt(Math.pow(b,2) - (4*a*c));
		System.out.println("1º resultado = "+ x1);
		System.out.println("2º resultado = "+ x2);
		}else if ( discriminante <0) {
			System.out.print("No hay solucion real");
		}else {
			int x = -b /(a*a);
			System.out.println("resultado = "+ x);
		}
		
	
	
	
	
	
	}
}