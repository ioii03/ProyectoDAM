package tareaCopiadaManu;

import java.util.Scanner;

public class Ejercicio6_SOBRE_SWITCH {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Scanner sc = new Scanner(System.in);
        System.out.print(" introduce un dia (Numero): ");
        int dia = sc.nextInt();
        System.out.print(" introduce un mes (Numero): ");
        int mes = sc.nextInt();
        System.out.print(" introduce un año: ");
        int año = sc.nextInt();
        sc.close();
        switch (mes) {
        case 2:

            if (dia == 28) {
                mes+=1;
                dia=1;
                System.out.println(dia +"/"+mes+"/"+año);
            }else {dia+=1; System.out.println(dia +"/"+mes+"/"+año);}
            break;
        case 4,6,9,11:
            if (dia == 30) {
                mes+=1;
                dia=1;
                System.out.println(dia +"/"+mes+"/"+año);
            }else {dia+=1; System.out.println(dia +"/"+mes+"/"+año);}
            break;
        case 1,3,5,7,8,10:
            if (dia == 31) {
                mes+=1;
                dia=1;
                System.out.println(dia +"/"+mes+"/"+año);
            }else {dia+=1; System.out.println(dia +"/"+mes+"/"+año);}
            break;
        case 12:
            if (dia == 31) {
                mes=1;
                dia=1;
                año+=1;
                System.out.println(dia +"/"+mes+"/"+año);
            }else {dia+=1; System.out.println(dia +"/"+mes+"/"+año);}
            break;
        default:
            System.out.println("ERROR");
            break;
        }
    }
}