package supermercadito;

public class Supermercado {

	
	
	
	
	public void enseñarSeccion(Seccion sec) {
		
		System.out.println("Sección: " +sec.getSecion());
		System.out.println("Estanteria: " +sec.getNpos());
		System.out.println("Posición del producto: " +sec.getNestante());		
		System.out.println();
	}
	
	
	public void enseñarProducto(Productos item) {
		
		System.out.println("Nombre del producto: " +item.getNombre());
		System.out.println("ID: " +item.getId());
		System.out.println("Precio: " +item.getPrecio() +"€");
	
		
	}
	
	public static void main(String[] args) {
		Supermercado supermercado = new Supermercado();
		Seccion sec1 = new Seccion(11, 12, 1);
		Seccion sec2 = new Seccion(22, 8, 2);
		Seccion sec3 = new Seccion(33, 21, 3);
		
		
		
		Productos pro1 = new Productos("Manzana", 523, 0.75);
		Productos pro2 = new Productos("Zanahoria", 671, 1.15);
		Productos pro3 = new Productos("Salmon", 172, 4.77);
		
		supermercado.enseñarProducto(pro1);
		supermercado.enseñarSeccion(sec1);
		supermercado.enseñarProducto(pro2);
		supermercado.enseñarSeccion(sec2);
		supermercado.enseñarProducto(pro3);
		supermercado.enseñarSeccion(sec3);
		
	
	}
	
	

	
	
}
/*
class Productos {
	
	private String nombre;
	private int id;
	private double precio;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	
	
	public Productos(String ProductoNombre, int id, double precio) {
		this.nombre = ProductoNombre;
		this.id = id;
		this.precio = precio;
	
	}
	
	
	
}
class Seccion {

	private int secion;
	private int npos;
	private int nestante;
	
	public int getNpos() {
		return npos;
	}
	public void setNpos(int npos) {
		this.npos = npos;
	}
	public int getNestante() {
		return nestante;
	}
	public void setNestante(int nestante) {
		this.nestante = nestante;
	}
	public int getSecion() {
		return secion;
	}
	public void setSeccion(int secion) {
		this.secion = secion;
	}
	
	public Seccion(int npos, int nestante, int secion) {
		this.npos = npos;
		this.nestante = nestante;
		this.secion = secion;
	}
	
	
}
*/


/*
1. Se desea realizar la abstracción necesaria para representar un supermercado.
Sabemos que existen productos, identificados por un id, nombre, sección y
precio. Se pide crear la clase correspondiente con todos aquellos métodos
necesarios para su correcto funcionamiento.

2. Partiendo de la clase anterior, suponemos que la sección es, a su vez, un
objeto diferente caracterizado por el número de posición y número de
estante. Realiza la abstracción necesaria de la sección y las modificaciones
necesarias en producto para que tenga en cuenta este nuevo tipo de objeto.
*/