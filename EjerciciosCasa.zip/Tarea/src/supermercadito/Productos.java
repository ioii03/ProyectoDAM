package supermercadito;

public class Productos {
	
	private String nombre;
	private int id;
	private double precio;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	
	
	public Productos(String ProductoNombre, int id, double precio) {
		this.nombre = ProductoNombre;
		this.id = id;
		this.precio = precio;
	
	}
	
	
	
}


/*
1. Se desea realizar la abstracción necesaria para representar un supermercado.
Sabemos que existen productos, identificados por un id, nombre, sección y
precio. Se pide crear la clase correspondiente con todos aquellos métodos
necesarios para su correcto funcionamiento.

*/