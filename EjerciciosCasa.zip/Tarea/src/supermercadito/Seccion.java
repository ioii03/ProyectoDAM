package supermercadito;

public class Seccion {

		private int secion;
		private int npos;
		private int nestante;
		
		public int getNpos() {
			return npos;
		}
		public void setNpos(int npos) {
			this.npos = npos;
		}
		public int getNestante() {
			return nestante;
		}
		public void setNestante(int nestante) {
			this.nestante = nestante;
		}
		public int getSecion() {
			return secion;
		}
		public void setSeccion(int secion) {
			this.secion = secion;
		}
		
		public Seccion(int npos, int nestante, int secion) {
			this.npos = npos;
			this.nestante = nestante;
			this.secion = secion;
		}
		
		
}

/*
2. Partiendo de la clase anterior, suponemos que la sección es, a su vez, un
objeto diferente caracterizado por el número de posición y número de
estante. Realiza la abstracción necesaria de la sección y las modificaciones
necesarias en producto para que tenga en cuenta este nuevo tipo de objeto.
*/