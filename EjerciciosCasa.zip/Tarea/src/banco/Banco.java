package banco;

public class Banco {

	private String titular;
	private int IBAN;
	private double saldo;
	
	public int getIBAN() {
		return this.IBAN;
	}
	public void setIBAN(int iBAN) {
		this.IBAN = iBAN;
	}
	public String getTitular() {
		return this.titular;
	}
	public void setTitular(String titular) {
		this.titular = titular;
	}
	public double getSaldo() {
		return this.saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public Banco(String titular, int IBAN, double saldo) {
		this.IBAN = IBAN;
		this.titular = titular;
		this.saldo = saldo;
	}


	public void IngresarDinero(double meterDinero){
		
		saldo +=meterDinero;
		
	}
	
	public void RetirarDinero(double sacarDinero) {
		saldo -= sacarDinero;
		
		if(saldo < 0 ) {
			
			System.out.println("No se puede retirar mas dinero del que se posee, se cancela la transacción.");
			saldo += sacarDinero;
		} 
	}
	
	public void CantidadSaldo() {
		//if(saldo > 0) {
			System.out.println("Saldo en la cuenta: "+saldo+"€");
			System.out.println();
		/*}else {
			System.out.println("Saldo insuficiente.");
			System.out.println();
		}*/
	}
	
	public void MostrarCuenta() {
		System.out.println("IBAN de la cuenta: " +IBAN);
		System.out.println("Titular de la cuenta: "+titular);
	
	}
	
}



/*
4. Se desea realizar la abstracción de una cuenta bancaria. Cada cuenta tiene
un número de cuenta, titular y saldo.
La clase deberá disponer de métodos que permitan:
• Ingresar dinero.
• Retirar dinero.
• Consultar el saldo.
• Mostrar los datos de la cuenta.
• No se permitirá retirar una cantidad superior al saldo disponible.
También debemos crear un main que pruebe la clase y métodos creados con 3
cuentas.
*/