package banco;

public class Empresa {

	
		private String nombre;
		private double sueldo;
		private int antiguedad;
		
		public String getNombre() {
			return this.nombre;
		}
		public void setNombre(String nombre) {
			this.nombre = nombre;
		}
		public double getSueldo() {
			return this.sueldo;
		}
		public void setSueldo(double sueldo) {
			this.sueldo = sueldo;
		}
		public int getAntiguedad() {
			return this.antiguedad;
		}
		public void setAntiguedad(int antiguedad) {
			this.antiguedad = antiguedad;
		}
		public Empresa(String nombre, double sueldo, int antiguedad) {
			this.nombre = nombre;
			this.sueldo = sueldo;
			this.antiguedad = antiguedad;
		}

		
		public void PagarNomina () {
			if(sueldo >= 1000 && antiguedad >= 3) {
				sueldo *= 1.1;
			}
			if (sueldo >=1500 && antiguedad>=3) {
				sueldo -=50;
			}
			if (sueldo >=2000 && sueldo<=3000 && antiguedad>=3) {
				sueldo *=0.98;
			}
			System.out.println("Salario de " +nombre +": " +(int)sueldo +"€");
			//System.out.println("Nomina Persona: " +getSueldo() +"€");
			
		}
		
		
		
		
		public static void main(String[] args) {
			
		//	Empresa emp1 = new Empresa("Aaron", 1000, 2);
			Empresa emp2 = new Empresa("Rodrigo", 1000, 3);
			Empresa emp3 = new Empresa("Nico", 1500, 3);
			Empresa emp4 = new Empresa("Juanjo", 3000, 3);
			//Empresa emp5 = new Empresa("Rocio", 4000, 3);
			//emp1.PagarNomina();
			emp2.PagarNomina();
			emp3.PagarNomina();
			emp4.PagarNomina();
			//emp5.PagarNomina();
			
		}


}




/*
3. Tenemos que calcular la nómina de un empleado de una empresa que está basada
en una serie de premisas para hacer los ajustes necesarios:
a. Si el empleado cobra más de 1000€ y tiene más de 3 años de antigüedad
se le incrementa en un 10% el sueldo.
b. Si el sueldo incrementado supera los 1500€ se le aplica una retención
de impuestos especial de 50€.
c. Si el empleado cobra entre 2000€ y 3000€ la retención es del 2%.
Se pide crear la abstracción correspondiente de un empleado, teniendo en cuenta
que se caracteriza por nombre, salario y antigüedad, generar 3 diferentes y
calcular su nómina, imprimiendo el resultado por pantalla.
4. Se desea realizar la abstracción de una cuenta bancaria. Cada cuenta tiene
un número de cuenta, titular y saldo.
La clase deberá disponer de métodos que permitan:
• Ingresar dinero.
• Retirar dinero.
• Consultar el saldo.
• Mostrar los datos de la cuenta.
• No se permitirá retirar una cantidad superior al saldo disponible.
También debemos crear un main que pruebe la clase y métodos creados con 3
cuentas.

*/