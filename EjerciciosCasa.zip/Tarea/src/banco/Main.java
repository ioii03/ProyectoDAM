package banco;

public class Main {
	public static void main(String[] args) {
	Banco c1 = new Banco("Nico", 1230, 1000);
	Banco c2 = new Banco("Juanjo", 1230, 500);
	Banco c3 = new Banco("Javier", 1230, 2000);
		
	
		c1.MostrarCuenta();
		c1.IngresarDinero(300);
		c1.RetirarDinero(2000);
		c1.CantidadSaldo();
		
		c2.MostrarCuenta();
		c2.IngresarDinero(30);
		c2.RetirarDinero(100);
		c2.CantidadSaldo();
		
		c3.MostrarCuenta();
		c3.IngresarDinero(400);
		c3.RetirarDinero(100);
		c3.CantidadSaldo();
	}
}




/*
4. Se desea realizar la abstracción de una cuenta bancaria. Cada cuenta tiene
un número de cuenta, titular y saldo.
La clase deberá disponer de métodos que permitan:
• Ingresar dinero.
• Retirar dinero.
• Consultar el saldo.
• Mostrar los datos de la cuenta.
• No se permitirá retirar una cantidad superior al saldo disponible.
También debemos crear un main que pruebe la clase y métodos creados con 3
cuentas.
*/

