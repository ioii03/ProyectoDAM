package animal;


		/*public class Animal {
	    private String nombre;
	    private String especie;
	    private Morfologia morfologia;

	    
	    
	    public String getEspecie() {
			return especie;
		}

		public void setEspecie(String especie) {
			this.especie = especie;
		}

		public void setNombre(String nombre) {
			this.nombre = nombre;
		}

		public void setMorfologia(Morfologia morfologia) {
			this.morfologia = morfologia;
		}

		// Constructor de Animal
	    public Animal(String nombre, String especie, int patas, double peso) {
	        this.nombre = nombre;
	        this.especie = especie;
	        this.morfologia = new Morfologia(patas, peso);
	    }

	    // Clase interna Morfologia
	    public static class Morfologia {
	        private int patas;
	        private double peso;

	        public Morfologia(int patas, double peso) {
	            this.patas = patas;
	            this.peso = peso;
	        }

	        public int getPatas() {
	            return patas;
	        }

	        public double getPeso() {
	            return peso;
	        }
	    }

	    public Morfologia getMorfologia() {
	        return morfologia;
	    }

	    public String getNombre() {
	        return nombre;
	    }

	    // Método para sumar las patas de este animal con otro
	    public int sumarPatas(Animal otroAnimal) {
	        return this.morfologia.getPatas() + otroAnimal.getMorfologia().getPatas();
	    }

	    public static void main(String[] args) {
	        // Crear dos animales
	        Animal perro = new Animal("Firulais", "Perro", 4, 15.5);
	        Animal pato = new Animal("Lucas", "Pato", 2, 2.3);

	        // Sumar las patas usando el método de la clase
	        int totalPatas = perro.sumarPatas(pato);

	        System.out.println("El total de patas de " + perro.getNombre() + " y " + pato.getNombre() + " es: " + totalPatas);
	    }
	}*/


	class Animal {
    private String nombre;
    private String especie;
    private Morfologia morfologia;

    // Constructor de Animal
    public Animal(String nombre, String especie, int patas, double peso) {
        this.nombre = nombre;
        this.especie = especie;
        this.morfologia = new Morfologia(patas, peso);
    }

    // Clase interna Morfologia
   class Morfologia {
        private int patas;
        private double peso;

        public Morfologia(int patas, double peso) {
            this.patas = patas;
            this.peso = peso;
        }

        public int getPatas() {
            return patas;
        }

        public double getPeso() {
            return peso;
        }
    }

    public Morfologia getMorfologia() {
        return morfologia;
    }

    public String getNombre() {
        return nombre;
    }

    // Método para sumar las patas de este animal con otro
    public int sumarPatas(Animal otroAnimal) {
        return this.morfologia.getPatas() + otroAnimal.getMorfologia().getPatas();
    }
    
    public static void main(String[] args) {
        // Crear dos animales
        Animal animal1 = new Animal("Firulais", "Perro", 4, 15.5);
        Animal animal2 = new Animal("Lucas", "Pato", 8, 2.3);

        // Sumar las patas usando el método de la clase
        int totalPatas = animal1.sumarPatas(animal2);

        System.out.println("El total de patas es: " + totalPatas);
    }
}
