package wasap; 

public class Main {
        public static void main(String[] args) {
               /* Empleado e1 = new Empleado("Omar", 1000.00, 2);
                Empleado e2 = new Empleado("Otman", 1500.00, 4);
                Empleado e3 = new Empleado("Ayman", 3000.00, 5);

                e1.pagarNomina();
                e2.pagarNomina();
                e3.pagarNomina();

                System.out.println();
                */
                cuentaBanco c1 = new cuentaBanco(1010, "Omar", -540);
                cuentaBanco c2 = new cuentaBanco(1011, "Otman", 23);
                cuentaBanco c3 = new cuentaBanco(1012, "Ayman", 129);

                c1.IngresarDinero(200);
                c1.RetirarDinero(2);
                c1.ConsultarSaldo();
                c1.ConsultarDatosCuenta();

                c2.IngresarDinero(20);
                c2.RetirarDinero(2);
                c2.ConsultarSaldo();
                c2.ConsultarDatosCuenta();
            
                c3.IngresarDinero(20);
                c3.RetirarDinero(2);
                c3.ConsultarSaldo();
                c3.ConsultarDatosCuenta();
                

                Alumno a1 = new Alumno("Omar", 01, 4, 1, 2.5);
                Alumno a2 = new Alumno("Otman", 02, 1, 9, 7);
                Alumno a3 = new Alumno("Ayman", 03, 9.5, 5, 9.9);

                a1.calcularMedia();
                a2.calcularMedia();
                a3.calcularMedia();
                
        }
}
