package wasap; 

public class Alumno {
        private String nombre;
        private int n_expediente;
        private double calificacion_1;
        private double calificacion_2;
        private double calificacion_3;

        public Alumno(String nombreAlumno, int n_expedienteAlumno, double calificacion_1Alumno, double calificacion_2Alumno, double calificacion_3Alumno){
                this.nombre = nombreAlumno;
                this.n_expediente = n_expedienteAlumno;
                this.calificacion_1 = calificacion_1Alumno;
                this.calificacion_2 = calificacion_2Alumno;
                this.calificacion_3 = calificacion_3Alumno;
        }

        public void calcularMedia() {
                if ((calificacion_1 + calificacion_2 + calificacion_3) / 3 < 5){
                        System.out.println("El alumno " + nombre + " esta suspenso");
                }
                
                if ((calificacion_1 + calificacion_2 + calificacion_3) / 3 > 5 && (calificacion_1 + calificacion_2 + calificacion_3) / 3 < 7 ){
                        System.out.println("El alumno " + nombre + " esta aprobado");
                }

                if ( (calificacion_1 + calificacion_2 + calificacion_3) / 3 > 7 && (calificacion_1 + calificacion_2 + calificacion_3) / 3 < 9){
                        System.out.println("El alumno " + nombre + " tiene un notable");
                }

                if ((calificacion_1 + calificacion_2 + calificacion_3) / 3 >= 9){
                        System.out.println("El alumno " + nombre + " tiene un sobresaliente");
                }
        }
}
// no.