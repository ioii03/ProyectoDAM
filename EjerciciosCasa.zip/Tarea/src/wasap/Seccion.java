package wasap; 

public class Seccion {
        
        private int posicion;
        private int numero_estante;

	public int getPosicion() {
		return this.posicion;
	}

	public void setPosicion(int posicion) {
		this.posicion = posicion;
	}

	public int getNumero_estante() {
		return this.numero_estante;
	}

	public void setNumero_estante(int numero_estante) {
		this.numero_estante = numero_estante;
	}

}
