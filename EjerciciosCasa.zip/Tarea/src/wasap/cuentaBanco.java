package wasap; 

public class cuentaBanco {
        private int IBAN;
        private String titular;
        private double saldo;

	public int getIBAN() {
		return this.IBAN;
	}

	public void setIBAN(int IBAN) {
		this.IBAN = IBAN;
	}

	public String getTitular() {
		return this.titular;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}

	public double getSaldo() {
		return this.saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

        public void IngresarDinero(double saldoIngresable){
                saldo += saldoIngresable;
        }

        public void RetirarDinero(double saldoRetirable) {
                saldo -= saldoRetirable;
        }

        public void ConsultarSaldo() {
                System.out.println("El saldo es " + saldo + "€");
        }

        public cuentaBanco(int IBAN_Cuenta, String titularCuenta, double saldoCuenta) {
                this.IBAN = IBAN_Cuenta;
                this.titular = titularCuenta;
                this.saldo = saldoCuenta;
        }

        public void ConsultarDatosCuenta() {
                System.out.println("El IBAN de la cuenta es " + IBAN);
                System.out.println("El titular de la cuenta bancaria es " + titular);
                System.out.println("El saldo disponible en la cuenta bancaria es de " + saldo + "€");
                System.out.println();
        }
 
        
}
