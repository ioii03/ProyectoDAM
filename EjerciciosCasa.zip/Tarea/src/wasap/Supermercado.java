package wasap; 
/* Se desea realizar la abstracción necesaria para representar un supermercado.
Sabemos que existen productos, identificados por un id, nombre, sección y
precio. Se pide crear la clase correspondiente con todos aquellos métodos
necesarios para su correcto funcionamiento. */

// este ejercicio esta tirado lmao
public class Supermercado {
        private String id;
        private String nombre;
        private String seccion;
        private double precio;

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getSeccion() {
		return this.seccion;
	}

	public void setSeccion(String seccion) {
		this.seccion = seccion;
	}

	public double getPrecio() {
		return this.precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}
        
        public static void main(String[] args){

        }

}
