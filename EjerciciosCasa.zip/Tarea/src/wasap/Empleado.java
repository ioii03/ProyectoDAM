package wasap; 

public class Empleado {
        private String nombre;
        private double salario;
        private int antiguedad;

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getSalario() {
		return this.salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public int getAntiguedad() {
		return this.antiguedad;
	}

	public void setAntiguedad(int antiguedad) {
		this.antiguedad = antiguedad;
	}

        public Empleado(String nombreEmpleado, double salarioEmpleado, int antiguedadEmpleado){
                this.nombre = nombreEmpleado;
                this.salario = salarioEmpleado;
                this.antiguedad = antiguedadEmpleado;
        }



        public void pagarNomina(){
                if (antiguedad >= 3 && salario > 1000){
                        salario *= 1.1;
                        
                }
                if (salario > 1500 && salario < 2000 ){
                        salario -= 50;
                        
                }
                if (salario > 2000 && salario < 3000){
                        salario *= 0.98;
                        
                }
                System.out.println("El salario del empleado " + nombre + " es de " + salario +"€");
               

        }
}